# DentAI Unified Platform

## 36-Module Complete Dental Practice Operating System

**One platform. Every workflow. Zero fragmentation.**

Replaces: Dentrix + CareStack + Overjet + Pearl + Weave + DentalRobot + Vyne + BastionGPT + Nexus + DataRovers + Dental Intelligence ($4,200+/mo combined)

### Quick Start

```bash
npm install
npm run dev
```

### Architecture

```
src/
├── main.jsx          # React entry point
├── App.jsx           # Sidebar navigation + module routing
├── theme.js          # Design tokens, colors, module definitions
├── ui.jsx            # Shared components (Badge, Kpi, Card, etc.)
└── views/
    ├── Clinical.jsx    # 7 modules: Intake, Perio, SOAP, Imaging, Consent, eRx, Decision Support
    ├── Specialty.jsx   # 4 modules: Ortho, Implant, Lab, Referrals
    ├── Operations.jsx  # 4 modules: Inventory, HR, Sterilization, Smart Schedule
    ├── Revenue.jsx     # 6 modules: RCM, Verify, Claims, Cross-Code, Necessity Letters, Denials
    ├── AIEngines.jsx   # 5 modules: Phone Agent, Voice-to-Code, Tx Planning, Case Acceptance, Telehealth
    └── Intelligence.jsx # 10 modules: Financial, Financing, Marketing, NPS, Fees, Provider, Payer, Multi-Location, Compliance, BI
```

### 36 Modules Across 6 Groups

| Group | Modules | Key Capabilities |
|-------|---------|-----------------|
| **Clinical** | 7 | Digital intake, perio charting, AI SOAP notes, diagnostic imaging, consent, eRx, decision support |
| **Specialty** | 4 | Ortho tracking, implant pipeline, lab management, referral network |
| **Operations** | 4 | Inventory, HR/payroll, sterilization/OSHA, AI scheduling |
| **Revenue AI** | 6 | Revenue command center, insurance verification, claims engine, cross-coding, necessity letters, denial appeals |
| **AI Engines** | 5 | 24/7 phone agent, voice-to-code, AI treatment planning, case acceptance, teledentistry |
| **Intelligence** | 10 | Financial center, patient financing, marketing, NPS, fee optimizer, provider/payer intelligence, multi-location, compliance, unified BI |

### Key Metrics (Sample Data)

- **$198,240** collections MTD (99.5% of net production)
- **94.2%** first-pass claim acceptance rate
- **18.4 days** in A/R (down from 32)
- **$141,600/mo** AI value attribution ($1.7M/year)
- **74%** case acceptance rate (up from 58% pre-AI)
- **$497/mo** platform cost vs $4,200+ fragmented

### Tech Stack

- React 18 + Vite
- Custom design system (dark theme)
- Outfit + JetBrains Mono fonts
- Zero external UI libraries
