import React from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Row, Grid } from "../ui";

// ═══ 12. INVENTORY ═══
export function InventoryView() {
  return (
    <Section title="📦 Inventory & Supply Management" sub="Auto-reorder, vendor comparison, expiration tracking">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📦" label="Total SKUs" value="342" color={C.accent} />
        <Kpi icon="⚠️" label="Low Stock" value="8" sub="3 critical" color={C.danger} />
        <Kpi icon="📅" label="Expiring <90d" value="12" color={C.warning} />
        <Kpi icon="💰" label="Monthly Spend" value="$11,400" sub="5.7% of production" color={C.teal} />
      </Grid>
      <Card>
        {[["Composite A2 (4g)","Restorative","12","10","Henry Schein","$42.50","Low",C.warning],["Implant Body 4.1×10","Implant","3","5","Straumann","$285","Critical",C.danger],["Nitrile Gloves (M)","PPE","24 boxes","10","Amazon","$12.99","OK",C.success],["Lidocaine 2%","Anesthesia","48 carp","20","Patterson","$28.50","OK",C.success],["Bite Registration","Impression","6","8","Dentsply","$34","Low",C.warning],["Sterilization Pouches","Infection Ctrl","2 boxes","5","Crosstex","$18.50","Critical",C.danger]].map(([item,cat,stock,reorder,vendor,cost,st,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.8fr 0.8fr 60px 60px 1fr 70px 70px",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{item}</span><span style={{color:C.muted}}>{cat}</span><span>{stock}</span><span style={{color:C.muted}}>{reorder}</span><span style={{color:C.muted}}>{vendor}</span><span style={{fontFamily:"'JetBrains Mono'"}}>{cost}</span><Badge color={color}>{st}</Badge>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 13. HR & PAYROLL ═══
export function HrView() {
  return (
    <Section title="👥 HR & Employee Management" sub="Time clock, PTO, scheduling, payroll, CE tracking, license alerts">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="👥" label="Total Staff" value="14" sub="3 providers, 11 team" color={C.accent} />
        <Kpi icon="⏰" label="Clocked In" value="12" sub="2 off today" color={C.success} />
        <Kpi icon="📅" label="PTO Requests" value="3" sub="2 pending" color={C.warning} />
        <Kpi icon="🎓" label="CE Expiring <90d" value="2" sub="Sarah M, Jamie L" color={C.danger} />
      </Grid>
      <Card>
        {[["Dr. Chen","Implantologist","In",C.success,"7:45 AM","8.2h","15d","Dec 2026"],["Dr. Park","Orthodontist","In",C.success,"7:50 AM","8.1h","12d","Mar 2027"],["Dr. Okafor","Oral Surgeon","In",C.success,"8:00 AM","8.0h","18d","Jun 2026"],["Sarah M. RDH","Hygienist","In",C.success,"7:55 AM","8.1h","8d","Apr 2026 ⚠️"],["Jamie L. RDH","Hyg/Perio","In",C.success,"8:00 AM","8.0h","6d","May 2026 ⚠️"],["Maria G.","Office Mgr","In",C.success,"7:30 AM","8.5h","10d","—"],["Tom R.","Front Desk","Off",C.muted,"—","—","5d","—"]].map(([name,role,st,color,cin,hrs,pto,lic],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.3fr 1fr 55px 60px 55px 55px 75px",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{name}</span><span style={{color:C.muted}}>{role}</span><Badge color={color}>{st}</Badge><span style={{color:C.muted}}>{cin}</span><span>{hrs}</span><span>{pto}</span><span style={{color:lic.includes("⚠")?C.danger:C.muted,fontWeight:lic.includes("⚠")?700:400}}>{lic}</span>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 14. STERILIZATION ═══
export function SterilizationView() {
  return (
    <Section title="🧪 Sterilization & OSHA Compliance" sub="Autoclave logs, biological indicators, compliance checklists">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🧪" label="Cycles Today" value="8" sub="All passed ✓" color={C.success} />
        <Kpi icon="🦠" label="Last Spore Test" value="Pass" sub="Feb 10, 2026" color={C.success} />
        <Kpi icon="📋" label="OSHA Compliance" value="98%" sub="1 item due" color={C.warning} />
        <Kpi icon="☢️" label="Radiation Badges" value="Current" sub="Next: Mar 1" color={C.teal} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>Today's Autoclave Log</CardTitle>
          {[1,2,3,4,5,6,7,8].map(i => (
            <Row key={i} bb={i<8}><span style={{fontSize:11}}>Cycle #{i} — {`${7+Math.floor(i/2)}:${i%2===0?"00":"30"} AM`}</span><div style={{display:"flex",gap:6}}><span style={{fontSize:10,color:C.muted}}>270°F / 30 min</span><Badge color={C.success}>Pass</Badge></div></Row>
          ))}
        </Card>
        <Card>
          <CardTitle>OSHA Compliance Checklist</CardTitle>
          {[["Exposure Control Plan","Annual","Jan 2026","current"],["Hazard Communication","Annual","Jan 2026","current"],["Bloodborne Pathogen Training","Annual","Dec 2025","current"],["Fire Safety Inspection","Annual","Nov 2025","current"],["Radiation Safety Certificate","Biennial","Mar 2024","due_soon"],["Emergency Eyewash Testing","Weekly","Feb 10","current"],["SDS Binder Updated","Ongoing","Feb 2026","current"]].map(([item,due,last,st],i) => (
            <Row key={i} bb={i<6}><span style={{fontSize:11}}>{item}</span><Badge color={st==="current"?C.success:C.warning}>{st==="current"?"Current":"Due Soon"}</Badge></Row>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 15. SMART SCHEDULING ═══
export function ScheduleView() {
  return (
    <Section title="📅 AI Scheduling & Capacity Optimizer" sub="Production-based scheduling, no-show prediction, same-day fill">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📅" label="Chair Utilization" value="91%" sub="Target: 85%" color={C.success} />
        <Kpi icon="💰" label="Tomorrow's Production" value="$24,800" color={C.accent} />
        <Kpi icon="⚠️" label="No-Show Risk" value="3" sub="AI sending reminders" color={C.warning} />
        <Kpi icon="🔄" label="Same-Day Fills" value="4" sub="From AI waitlist" color={C.emerald} />
      </Grid>
      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:14}}>
        <Card>
          <CardTitle>📅 Tomorrow's Schedule</CardTitle>
          {[["8:00","60m","Op 1","Dr. Chen","Robert Kim","Implant Consult + CBCT","$2,450","low"],["8:00","60m","Op 2","Dr. Park","Diana Patel","Invisalign Check #9","$280","low"],["8:00","60m","Hyg 1","Sarah RDH","James Okafor","Perio Maintenance","$180","med"],["8:00","60m","Hyg 2","Jamie RDH","New Pt — Garcia","NP Exam + BWX","$342","high"],["9:00","90m","Op 1","Dr. Chen","Margaret Sullivan","Crown Seat #14","$1,280","low"],["9:00","60m","Op 2","Dr. Park","Tyler Nguyen","Ortho Consult","$250","med"],["10:00","120m","Op 1","Dr. Chen","Michael Torres","Crown Prep #3","$1,840","low"]].map(([time,dur,chair,prov,pt,proc,prod,risk],i) => (
            <div key={i} style={{display:"grid",gridTemplateColumns:"45px 40px 50px 70px 1fr 1.2fr 70px 45px",padding:"6px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:10}}>
              <span style={{fontFamily:"'JetBrains Mono'",fontWeight:700,color:C.accent}}>{time}</span>
              <span style={{color:C.muted}}>{dur}</span>
              <span style={{color:C.muted}}>{chair}</span>
              <span style={{fontWeight:600,fontSize:9}}>{prov}</span>
              <span style={{fontWeight:700}}>{pt}</span>
              <span style={{color:"#7A8298",fontSize:9}}>{proc}</span>
              <span style={{fontWeight:800,color:C.emerald,fontFamily:"'JetBrains Mono'"}}>{prod}</span>
              <Badge color={risk==="high"?C.danger:risk==="med"?C.warning:C.success}>{risk}</Badge>
            </div>
          ))}
        </Card>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <Card>
            <CardTitle>⚠️ No-Show Risk</CardTitle>
            {[["Maria Garcia (New)","38%","New pt, no deposit",C.danger],["James Okafor","22%","Missed last 2 hyg",C.warning],["Tyler Nguyen","18%","History of reschedule",C.warning]].map(([p,risk,reason,color],i) => (
              <div key={i} style={{padding:"6px 8px",background:`${color}05`,borderRadius:7,marginBottom:5}}>
                <Row><span style={{fontSize:10,fontWeight:700}}>{p}</span><Badge color={color}>{risk}</Badge></Row>
                <div style={{fontSize:9,color:C.muted}}>{reason}</div>
              </div>
            ))}
          </Card>
          <Card>
            <CardTitle>🔄 AI Waitlist</CardTitle>
            {[["Frank Morris","Crown seat #8","$1,280","Any AM"],["Karen Brown","Filling #18","$240","Tue/Thu PM"],["Pete Hall","Implant F/U","$0","Flexible"]].map(([p,proc,prod,flex],i) => (
              <Row key={i} bb={i<2}><div><span style={{fontSize:10,fontWeight:700}}>{p}</span><br/><span style={{fontSize:9,color:C.muted}}>{proc}</span></div><div style={{textAlign:"right"}}><span style={{fontSize:10,fontWeight:700,color:C.emerald}}>{prod}</span><br/><span style={{fontSize:9,color:C.muted}}>{flex}</span></div></Row>
            ))}
            <div style={{fontSize:9,color:C.success,marginTop:4}}>🤖 Cancellation → AI contacts waitlist in 30 sec</div>
          </Card>
        </div>
      </div>
    </Section>
  );
}
