import React from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Row, Grid, Alert, Metric } from "../ui";

// ═══ 22. AI PHONE AGENT ═══
export function PhoneView() {
  return (
    <Section title="📞 AI Phone & Communication Agent" sub="24/7 AI receptionist — replaces HeyGent + Weave AI">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📞" label="Calls Today" value="67" sub="42 AI, 25 staff" color={C.accent} />
        <Kpi icon="🤖" label="AI Resolution" value="84%" sub="No staff needed" color={C.success} />
        <Kpi icon="📅" label="Appts Booked" value="18" sub="11 AI, 7 staff" color={C.cyan} />
        <Kpi icon="💰" label="Revenue Recovered" value="$4,200" sub="Missed call follow-up" color={C.emerald} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>📞 Live Call Feed <Badge color={C.success} solid pulse>LIVE</Badge></CardTitle>
          {[["2:42 PM","New — Maria Garcia","3:12","AI","Booked NP exam 02/18. Collected insurance (Delta PPO). Sent intake SMS.","resolved",C.success],["2:38 PM","Diana Patel","1:45","AI","Confirmed Invisalign check 02/14. Asked about whitening — offered consult.","resolved",C.success],["2:31 PM","Unknown 916-555-8821","2:08","AI","Insurance implant question. Explained benefits. Booked free consult.","resolved",C.success],["2:24 PM","Tom Davis","0:45","AI","Rx refill request. Flagged for Dr. Chen approval.","escalated",C.warning],["2:18 PM","Dr. Anderson's Office","2:30","Staff","Specialist referral — transferred to Maria G.","transferred",C.accent],["1:55 PM","Missed 916-555-3344","—","AI","Auto-callback <2 min. New patient booked 02/20 8AM.","recovered",C.emerald]].map(([time,caller,dur,type,action,st,color],i) => (
            <div key={i} style={{padding:"6px 8px",borderLeft:`2px solid ${color}30`,borderRadius:"0 7px 7px 0",marginBottom:5,background:`${color}03`}}>
              <Row><div><span style={{fontSize:10,fontWeight:700}}>{caller}</span><span style={{fontSize:9,color:C.muted,marginLeft:5}}>{time} · {dur}</span></div><div style={{display:"flex",gap:3}}><Badge color={type==="AI"?C.accent:C.teal}>{type}</Badge><Badge color={color}>{st}</Badge></div></Row>
              <div style={{fontSize:9,color:"#7A8298",marginTop:1}}>{action}</div>
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>🤖 AI Agent Capabilities</CardTitle>
          {["📞 Answer with practice greeting","📅 Book/reschedule/cancel appts","🔍 Verify insurance on call","📱 Send intake forms via SMS","❓ Answer FAQs (hours, services, pricing)","🚨 After-hours emergency triage","↩️ Auto-callback missed calls <2min","📲 Reactivation calls to overdue patients","💰 Collections reminder calls","🌐 Spanish/Mandarin/Vietnamese","👤 Escalate with full context","📝 Record & transcribe all calls"].map((c,i) => (
            <Row key={i} bb={i<11}><span style={{fontSize:10}}>{c}</span><Badge color={C.success}>Active</Badge></Row>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 23. VOICE-TO-CODE PIPELINE ═══
export function VoiceView() {
  return (
    <Section title="🎤 Voice-to-Code Pipeline" sub="Speak naturally → SOAP note → CDT codes → claim ready">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🎤" label="Voice Notes Today" value="24" sub="6.8 hrs saved" color={C.cyan} />
        <Kpi icon="⚡" label="Processing Speed" value="2.8 sec" color={C.success} />
        <Kpi icon="✅" label="Auto-Coded" value="98.4%" color={C.emerald} />
        <Kpi icon="📋" label="Claims Generated" value="22" sub="From voice notes" color={C.accent} />
      </Grid>
      <Card>
        <CardTitle>🎤 Recent Voice Transcriptions</CardTitle>
        <div style={{padding:"12px 14px",background:`${C.cyan}05`,borderLeft:`3px solid ${C.cyan}`,borderRadius:"0 10px 10px 0",marginBottom:10}}>
          <div style={{fontSize:10,fontWeight:800,color:C.cyan,marginBottom:6}}>Dr. Chen — Michael Torres — 2:18 PM</div>
          {[["S","Patient presents for implant follow-up #17. Reports mild tenderness, no pain. Chewing carefully.",C.accent],["O","Implant #17 stable. Tissue healing well. No suppuration. Probing 2mm circumferential. Occlusion checked.",C.teal],["A","Implant #17 osseointegration progressing normally at 8 weeks.",C.purple],["P","Continue soft diet 2 weeks. Return 4 weeks for final impression. D6058 abutment + D6065 crown.",C.orange]].map(([label,text,color],i) => (
            <div key={i} style={{marginBottom:4,padding:"4px 8px",borderLeft:`2px solid ${color}30`,borderRadius:"0 6px 6px 0"}}>
              <span style={{fontSize:9,fontWeight:800,color}}>{label}: </span>
              <span style={{fontSize:10,color:"#8892A8"}}>{text}</span>
            </div>
          ))}
          <div style={{marginTop:6,display:"flex",gap:4}}>
            <Badge color={C.accent}>D6058 — $950</Badge>
            <Badge color={C.purple}>D6065 — $1,650</Badge>
            <Badge color={C.success} solid>AUTO-CODED</Badge>
          </div>
        </div>
      </Card>
    </Section>
  );
}

// ═══ 24. AI TREATMENT PLANNING ═══
export function TxPlanView() {
  return (
    <Section title="🧠 AI Treatment Planning Assistant" sub="Upload imaging → AI suggests diagnosis + CDT codes + fee estimates + insurance predictions">
      <Grid cols={2}>
        <Card>
          <CardTitle>🧠 AI Analysis — Robert Kim</CardTitle>
          <div style={{fontSize:10,color:C.muted,marginBottom:8}}>Based on: CBCT, periapical #14, FMX, clinical notes</div>
          {[["Missing tooth #14 — moderate bone loss mesial","K08.1","98%",C.danger],["Sufficient bone for implant (12mm)","Favorable","94%",C.success],["Adjacent #13, #15 — healthy","No contraindication","96%",C.success],["Sinus proximity — 3mm clearance","No sinus lift needed","87%",C.warning]].map(([finding,dx,conf,color],i) => (
            <Alert key={i} color={color} icon="" title={finding}>{dx} · Confidence: <strong>{conf}</strong></Alert>
          ))}
        </Card>
        <Card>
          <CardTitle>📋 AI-Generated Treatment Plan</CardTitle>
          {[{phase:"Phase 1 — Implant Placement",items:[["D6010","Implant body #14",2200,880],["D0367","CBCT",250,175]]},{phase:"Phase 2 — Restoration",items:[["D6058","Abutment placement",950,380],["D6065","Implant crown — porcelain",1650,660]]}].map((p,pi) => (
            <div key={pi} style={{marginBottom:10}}>
              <div style={{fontSize:10,fontWeight:800,color:C.purple,marginBottom:4}}>{p.phase}</div>
              {p.items.map(([cdt,desc,fee],ii) => (
                <Row key={ii} bb><span style={{color:C.accent,fontFamily:"'JetBrains Mono'",fontSize:10}}>{cdt}</span><span style={{flex:1,marginLeft:8,fontSize:10}}>{desc}</span><span style={{fontWeight:700,fontFamily:"'JetBrains Mono'",fontSize:10}}>${fee}</span></Row>
              ))}
            </div>
          ))}
          <div style={{background:C.card2,borderRadius:8,padding:"10px 12px",marginTop:8}}>
            <Row><span style={{fontSize:13,fontWeight:900}}>Total</span><span style={{fontSize:13,fontWeight:900,fontFamily:"'JetBrains Mono'"}}>$5,050</span></Row>
            <Row><span style={{fontSize:11,color:C.success}}>Est. Insurance</span><span style={{fontSize:11,color:C.success,fontFamily:"'JetBrains Mono'"}}>$2,095</span></Row>
            <Row><span style={{fontSize:12,fontWeight:900,color:C.danger}}>Patient Responsibility</span><span style={{fontSize:12,fontWeight:900,color:C.danger,fontFamily:"'JetBrains Mono'"}}>$2,955</span></Row>
            <div style={{fontSize:10,color:C.muted,marginTop:4}}>💳 Payment option: $123.13/mo × 24 months</div>
          </div>
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 25. CASE ACCEPTANCE ENGINE ═══
export function AcceptanceView() {
  return (
    <Section title="🎯 AI Case Acceptance Engine" sub="Visual treatment presentation, financing integration, AI follow-up sequences">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🎯" label="Acceptance Rate" value="74%" sub="↑ from 58% pre-AI" color={C.success} />
        <Kpi icon="💰" label="Presented MTD" value="$186,400" color={C.accent} />
        <Kpi icon="✅" label="Accepted MTD" value="$138,000" sub="74% of presented" color={C.emerald} />
        <Kpi icon="⏳" label="Pending" value="$32,800" sub="18 pts — AI following up" color={C.warning} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>🎯 Active Presentations</CardTitle>
          {[["Robert Kim","Implant #14","$5,050","$2,095","$2,955","$123/mo","pending",3,C.warning],["Margaret Sullivan","Crown #3 + SRP","$2,100","$1,240","$860","$143/mo","accepted",0,C.success],["Sophia Adams","Invisalign Full","$5,500","$2,000","$3,500","$291/mo","pending",7,C.warning],["Tom Davis","Full Arch","$24,800","$4,000","$20,800","$433/mo","pending",14,C.danger],["Emma Rodriguez","Veneers ×4","$6,400","$0","$6,400","$266/mo","declined",5,C.danger]].map(([p,tx,total,ins,oop,mo,st,days,color],i) => (
            <div key={i} style={{padding:"8px 10px",borderLeft:`3px solid ${color}25`,borderRadius:"0 8px 8px 0",marginBottom:6,background:`${color}03`}}>
              <Row><div><span style={{fontSize:11,fontWeight:800}}>{p}</span><span style={{fontSize:9,color:C.muted,marginLeft:5}}>{days}d ago</span></div><Badge color={color}>{st}</Badge></Row>
              <div style={{fontSize:10,color:"#8892A8",marginBottom:4}}>{tx}</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:4,fontSize:9}}>
                <Metric label="Total" value={total} /><Metric label="Insurance" value={ins} color={C.success} /><Metric label="OOP" value={oop} color={C.warning} /><Metric label="Monthly" value={mo} color={C.cyan} />
              </div>
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>📊 Objection Analysis</CardTitle>
          {[["Too expensive",42,"Auto-show monthly payment",C.danger],["Need to think",28,"3-day follow-up w/ education",C.warning],["Not sure necessary",18,"Send AI X-ray overlay",C.orange],["Want 2nd opinion",8,"Share clinical guidelines",C.accent],["Dental anxiety",4,"Offer sedation + testimonials",C.purple]].map(([obj,pct,ai,color],i) => (
            <div key={i} style={{marginBottom:7}}>
              <Row><span style={{fontSize:10}}>{obj}</span><span style={{fontSize:10,fontWeight:700,color}}>{pct}%</span></Row>
              <Pbar v={pct} color={color} h={3} />
              <div style={{fontSize:9,color:C.success,marginTop:1}}>🤖 {ai}</div>
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 26. TELEDENTISTRY ═══
export function TelehealthView() {
  return (
    <Section title="📹 Teledentistry Module" sub="HIPAA video consults, photo triage, remote monitoring (D9995/D9996)">
      <Grid cols={3} style={{marginBottom:14}}>
        <Kpi icon="📹" label="Video Consults MTD" value="24" sub="$4,800 billed" color={C.accent} />
        <Kpi icon="📸" label="Photo Triage" value="18" sub="12 → in-office, 6 → advice" color={C.purple} />
        <Kpi icon="✅" label="Post-Op Checks" value="34" sub="0 complications" color={C.success} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>📅 Today's Telehealth Queue</CardTitle>
          {[["Sarah Chen","Implant consult (new lead)","11:00 AM","video","waiting",C.warning],["Tom Davis","Post-op check (extraction)","1:00 PM","video","scheduled",C.accent],["Nina Fox","Photo triage (swelling)","ASAP","photo","urgent",C.danger]].map(([p,reason,time,type,st,color],i) => (
            <div key={i} style={{padding:"7px 0",borderBottom:i<2?`1px solid ${C.border}`:"none"}}>
              <Row><span style={{fontSize:11,fontWeight:700}}>{p}</span><Badge color={color}>{st}</Badge></Row>
              <div style={{fontSize:10,color:C.muted}}>{reason} · {time} · {type}</div>
            </div>
          ))}
        </Card>
        <div style={{background:"#0A0C14",borderRadius:14,padding:20,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:180,border:`1px solid ${C.border}`}}>
          <div style={{fontSize:40,marginBottom:8}}>📹</div>
          <div style={{color:C.muted,fontSize:13,fontWeight:600,marginBottom:14}}>HIPAA-Compliant Video Room</div>
          <button style={{background:C.success,color:"#FFF",border:"none",borderRadius:10,padding:"10px 28px",fontWeight:800,fontSize:13}}>Start Video Consult</button>
        </div>
      </Grid>
    </Section>
  );
}
