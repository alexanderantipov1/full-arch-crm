import React from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Row, Grid, Alert } from "../ui";

// ═══════════════════════════════════════════════════════════════
// 1. PATIENT INTAKE & PORTAL
// ═══════════════════════════════════════════════════════════════
export function IntakeView() {
  return (
    <Section title="📋 Digital Intake & Patient Portal" sub="Online forms, e-signatures, insurance card capture, patient self-service">
      <Grid cols={4} style={{ marginBottom: 14 }}>
        <Kpi icon="📋" label="Forms Today" value="12" sub="8 new patients" color={C.accent} />
        <Kpi icon="✍️" label="E-Signatures" value="34" sub="100% HIPAA compliant" color={C.success} />
        <Kpi icon="📸" label="Insurance Cards" value="11" sub="Auto-verified OCR" color={C.purple} />
        <Kpi icon="⏱️" label="Avg Intake Time" value="4.2m" sub="↓ from 18m paper" color={C.teal} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>📋 Active Intake Forms</CardTitle>
          {["New Patient Registration|24|98%","Medical History Questionnaire|42|96%","HIPAA Privacy Acknowledgment|3|100%","Financial Policy Agreement|5|99%","Insurance Card Upload|2|94%","Consent for Treatment|4|100%","Orthodontic Consent|12|97%","Implant Surgical Consent|8|95%"].map((f,i) => {
            const [name,fields,comp] = f.split("|");
            return <Row key={i} bb={i<7}><div><div style={{fontSize:12,fontWeight:600}}>{name}</div><div style={{fontSize:10,color:C.muted}}>{fields} fields</div></div><div style={{display:"flex",gap:6,alignItems:"center"}}><span style={{fontSize:11,color:C.success,fontWeight:600}}>{comp}</span><Badge color={C.success}>Active</Badge></div></Row>;
          })}
        </Card>
        <Card>
          <CardTitle>🌐 Patient Portal Features</CardTitle>
          {["📅 View & manage appointments|live","💳 Pay bills & view statements|live","💬 Message practice securely|live","📋 View treatment plans & accept|live","📄 Download receipts & EOBs|live","🏥 Update medical history|live","📸 Upload insurance card photos|live","💊 Request prescription refills|live","🔬 View X-rays & photos|beta","📹 Book teledentistry consult|beta"].map((f,i) => {
            const [feat,status] = f.split("|");
            return <Row key={i} bb={i<9}><span style={{fontSize:12}}>{feat}</span><Badge color={status==="live"?C.success:C.warning}>{status}</Badge></Row>;
          })}
        </Card>
      </Grid>
      <div style={{ background: `${C.accent}05`, border: `1px solid ${C.accent}12`, borderRadius: 12, padding: "14px 18px", marginTop: 12 }}>
        <div style={{ fontSize: 12, fontWeight: 800, marginBottom: 6 }}>🤖 AI Intake Automation Flow</div>
        <Grid cols={4} gap={8}>
          {[["1. Pre-Visit (48hr)","SMS sent → patient fills forms on phone → insurance card OCR extracts plan info",C.accent],["2. Auto-Verify","Eligibility checked instantly → benefits populated → copay calculated → estimates ready",C.purple],["3. Day-Of","QR code check-in → med hx flagged → allergies populated → zero clipboard time",C.success],["4. Post-Visit","Portal activated → treatment plan viewable → payment link → next appt booked",C.orange]].map(([t,d,c],i) => (
            <div key={i} style={{fontSize:11,color:"#7A8298"}}><strong style={{color:c}}>{t}:</strong> {d}</div>
          ))}
        </Grid>
      </div>
    </Section>
  );
}

// ═══════════════════════════════════════════════════════════════
// 2. PERIO CHARTING
// ═══════════════════════════════════════════════════════════════
export function PerioView() {
  const teeth = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16];
  const lower = [32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17];
  const probing = {3:[3,2,3,4,5,3],8:[2,2,2,2,3,2],14:[5,6,4,4,5,6],19:[4,3,3,3,4,4],30:[6,7,5,5,6,7]};
  return (
    <Section title="📊 Periodontal Charting" sub="6-point probing, BOP, recession, furcation, mobility — full perio record">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📏" label="Avg Probing" value="3.2mm" sub="Previous: 3.8mm ↓" color={C.success} />
        <Kpi icon="🩸" label="BOP Sites" value="18%" sub="Target: <10%" color={C.danger} />
        <Kpi icon="📉" label="Sites >4mm" value="24" sub="Previous: 31 ↓" color={C.warning} />
        <Kpi icon="🦷" label="Perio Dx" value="Stage III" sub="Grade B — generalized" color={C.purple} />
      </Grid>
      <Card style={{marginBottom:14}}>
        <CardTitle>Probing Chart — Margaret Sullivan — 2026-02-11</CardTitle>
        {[{label:"Facial — Upper",t:teeth,s:"F"},{label:"Lingual — Upper",t:teeth,s:"L"},{label:"Facial — Lower",t:lower,s:"F"},{label:"Lingual — Lower",t:lower,s:"L"}].map((row,ri) => (
          <div key={ri} style={{marginBottom:10}}>
            <div style={{fontSize:9,color:C.muted,fontWeight:700,letterSpacing:1.5,textTransform:"uppercase",marginBottom:3}}>{row.label}</div>
            <div style={{display:"flex",gap:2}}>
              {row.t.map(t => {
                const p = probing[t]||[2,2,2,2,2,2];
                const vals = row.s==="F"?p.slice(0,3):p.slice(3,6);
                return (
                  <div key={t} style={{flex:1,textAlign:"center"}}>
                    <div style={{display:"flex",justifyContent:"center",gap:1,marginBottom:2}}>
                      {vals.map((v,vi) => (
                        <div key={vi} style={{width:13,height:17,borderRadius:3,background:v>=6?`${C.danger}18`:v>=4?`${C.warning}18`:"#1A1D2E",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:v>=6?C.danger:v>=4?C.warning:C.success,fontFamily:"'JetBrains Mono'"}}>{v}</div>
                      ))}
                    </div>
                    <div style={{fontSize:8,fontWeight:700,color:C.muted}}>{t}</div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        <div style={{display:"flex",gap:14,paddingTop:8,borderTop:`1px solid ${C.border}`,marginTop:6}}>
          {[["1-3mm",C.success,"Healthy"],["4-5mm",C.warning,"Moderate"],["6mm+",C.danger,"Severe"]].map(([r,c,l]) => (
            <div key={r} style={{display:"flex",alignItems:"center",gap:4}}>
              <div style={{width:10,height:10,borderRadius:3,background:`${c}18`,border:`1px solid ${c}`}} />
              <span style={{fontSize:9,color:C.muted}}>{r} — {l}</span>
            </div>
          ))}
        </div>
      </Card>
      <Alert color={C.purple} icon="🤖" title="AI Perio Assessment">
        Diagnosis: <strong>Periodontitis Stage III, Grade B, Generalized</strong>. 24 sites ≥4mm (improved from 31). BOP at 18%. Recommend: continued SRP, 3-month perio maintenance, consider Arestin for sites ≥5mm. Insurance narrative auto-generated for D4341/D4342.
      </Alert>
    </Section>
  );
}

// ═══════════════════════════════════════════════════════════════
// 3. CLINICAL NOTES / SOAP
// ═══════════════════════════════════════════════════════════════
export function SoapView() {
  return (
    <Section title="📝 Clinical Notes — AI-Assisted SOAP" sub="Voice-to-text, AI expansion, CDT auto-coding, template library">
      <Grid cols={2}>
        <Card>
          <CardTitle>Today's Notes</CardTitle>
          {[["Margaret Sullivan","Implant Follow-up #14","8:00 AM","signed","Dr. Chen"],["Robert Kim","Implant Consult + CBCT","9:00 AM","draft","Dr. Chen"],["James Okafor","Perio Maintenance","8:00 AM","signed","Dr. Park"],["Diana Patel","Invisalign Check #8","9:00 AM","pending","Dr. Park"]].map(([p,proc,t,st,prov],i) => (
            <Row key={i} bb={i<3}><div><div style={{fontSize:12,fontWeight:700}}>{p}</div><div style={{fontSize:10,color:C.muted}}>{proc} · {t} · {prov}</div></div><Badge color={st==="signed"?C.success:st==="draft"?C.warning:C.muted}>{st}</Badge></Row>
          ))}
        </Card>
        <Card>
          <CardTitle>📋 SOAP Note — Margaret Sullivan</CardTitle>
          {[["S — Subjective","Patient reports mild sensitivity at implant site #14 when chewing. No spontaneous pain. Ibuprofen provides relief.",C.accent],["O — Objective","Implant #14 stable, no mobility. Tissue healthy. Probing: 3mm circumferential. CBCT confirms osseointegration at 6 weeks.",C.teal],["A — Assessment","Implant #14 healing within normal parameters. Sensitivity consistent with early loading adaptation.",C.purple],["P — Plan","Continue soft diet 2 weeks. Return 8 weeks for final impression (D6058 + D6065). Home care instructions given.",C.orange]].map(([label,text,color],i) => (
            <div key={i} style={{marginBottom:8,padding:"8px 10px",background:`${color}05`,borderLeft:`3px solid ${color}25`,borderRadius:"0 8px 8px 0"}}>
              <div style={{fontSize:9,fontWeight:800,color,letterSpacing:1,textTransform:"uppercase",marginBottom:2}}>{label}</div>
              <div style={{fontSize:11,color:"#8892A8",lineHeight:1.5}}>{text}</div>
            </div>
          ))}
          <div style={{display:"flex",gap:5,marginTop:6}}>
            <button style={{background:C.success,color:"#FFF",border:"none",borderRadius:7,padding:"5px 12px",fontSize:10,fontWeight:700}}>✓ Sign</button>
            <button style={{background:`${C.accent}12`,color:C.accent,border:`1px solid ${C.accent}20`,borderRadius:7,padding:"5px 12px",fontSize:10,fontWeight:700}}>🎤 Voice</button>
            <button style={{background:C.card2,border:`1px solid ${C.border}`,borderRadius:7,padding:"5px 12px",fontSize:10,fontWeight:600,color:C.text}}>🤖 AI Expand</button>
          </div>
        </Card>
      </Grid>
    </Section>
  );
}

// ═══════════════════════════════════════════════════════════════
// 4. AI DIAGNOSTIC IMAGING
// ═══════════════════════════════════════════════════════════════
export function ImagingView() {
  return (
    <Section title="🔬 AI Diagnostic Imaging Engine" sub="Real-time radiograph analysis, caries & bone loss detection — replaces Overjet + Pearl + VideaHealth">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🔬" label="Scans Analyzed" value="42" sub="38 BWX, 4 CBCT" color={C.accent} />
        <Kpi icon="🦷" label="Pathologies Found" value="18" sub="12 caries, 4 bone, 2 other" color={C.danger} />
        <Kpi icon="📊" label="Detection Accuracy" value="96.2%" sub="Validated vs provider dx" color={C.success} />
        <Kpi icon="💰" label="Revenue Found" value="$8,400" sub="AI-detected treatment" color={C.emerald} />
      </Grid>
      <div style={{display:"grid",gridTemplateColumns:"5fr 3fr",gap:14}}>
        <div style={{background:"#0A0C14",borderRadius:14,padding:"18px",border:`1px solid ${C.border}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
            <span style={{fontSize:13,fontWeight:800}}>Margaret Sullivan — BWX R/L</span>
            <Badge color={C.success} solid>AI ANALYZED</Badge>
          </div>
          <Grid cols={2} gap={8} style={{marginBottom:10}}>
            {[{label:"BWX — Right",findings:[{tooth:"#3 Mesial",type:"Caries",conf:94,sev:"moderate",color:C.danger},{tooth:"#14 Mesial",type:"Bone Loss",conf:89,sev:"4.2mm",color:C.purple}]},{label:"BWX — Left",findings:[{tooth:"#19 Distal",type:"Caries",conf:87,sev:"early",color:C.warning},{tooth:"#30 Mesial",type:"Bone Loss",conf:91,sev:"5.8mm",color:C.danger},{tooth:"#31 Periapical",type:"Radiolucency",conf:78,sev:"eval",color:C.orange}]}].map((xr,xi) => (
              <div key={xi} style={{background:"#060810",borderRadius:10,padding:"12px",border:"1px solid #1A1D2E"}}>
                <div style={{fontSize:9,color:C.muted,letterSpacing:1.5,textTransform:"uppercase",fontWeight:700,marginBottom:8}}>{xr.label}</div>
                <div style={{display:"flex",justifyContent:"center",height:70,background:"#040608",borderRadius:7,marginBottom:8,alignItems:"center",position:"relative",border:"1px solid #141720"}}>
                  <span style={{fontSize:28,opacity:0.15}}>🦷</span>
                  {xr.findings.map((f,fi) => <div key={fi} style={{position:"absolute",top:4+fi*22,right:4,background:`${f.color}18`,border:`1px solid ${f.color}35`,borderRadius:5,padding:"2px 6px"}}><span style={{fontSize:8,color:f.color,fontWeight:700}}>⚠ {f.tooth}</span></div>)}
                </div>
                {xr.findings.map((f,fi) => (
                  <div key={fi} style={{padding:"4px 0",borderBottom:fi<xr.findings.length-1?`1px solid ${C.border}`:"none"}}>
                    <Row><span style={{fontSize:10,fontWeight:700,color:f.color}}>{f.type} — {f.tooth}</span><Badge color={f.color}>{f.sev}</Badge></Row>
                    <div style={{display:"flex",alignItems:"center",gap:5,marginTop:2}}><Pbar v={f.conf} color={f.color} h={3} /><span style={{fontSize:9,color:f.color,fontWeight:700,fontFamily:"'JetBrains Mono'"}}>{f.conf}%</span></div>
                  </div>
                ))}
              </div>
            ))}
          </Grid>
          <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
            {["AI Overlay","Bone Levels","Caries Map","Compare","Enhance","Annotate","Patient View","Export"].map(t => (
              <button key={t} style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:6,padding:"5px 8px",color:"#5C6478",fontSize:9,fontWeight:600,flex:1,minWidth:60}}>{t}</button>
            ))}
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <Card>
            <CardTitle>🧠 AI Diagnostic Summary</CardTitle>
            <Alert color={C.danger} icon="🦷" title="3 Carious Lesions">#3M (94%), #19D (87%), #14M (82%)</Alert>
            <Alert color={C.purple} icon="📏" title="Bone Loss Quantified">#14M: 4.2mm (30%) · #30M: 5.8mm (45%). Stage III Perio.</Alert>
            <Alert color={C.orange} icon="⚠️" title="Periapical Finding">#31: Radiolucency 3×4mm — vitality test + PA recommended</Alert>
          </Card>
          <Card>
            <CardTitle>💰 AI Treatment Opportunity</CardTitle>
            {[["D2391 ×2 — Composite #3M, #19D","$480",C.accent],["D4341 ×4 — SRP all quadrants","$820",C.purple],["D0220 — PA #31 (diagnostic)","$35",C.teal],["D3310 — RCT #31 (if non-vital)","$980",C.orange]].map(([p,f,c],i) => (
              <Row key={i} bb><span style={{fontSize:10,color:"#8892A8"}}>{p}</span><span style={{fontWeight:700,color:c,fontFamily:"'JetBrains Mono'",fontSize:11}}>{f}</span></Row>
            ))}
            <Row style={{paddingTop:8,borderTop:`2px solid ${C.border}`,marginTop:4}}><span style={{fontSize:13,fontWeight:900}}>Potential Revenue</span><span style={{fontSize:15,fontWeight:900,color:C.emerald,fontFamily:"'JetBrains Mono'"}}>$2,315</span></Row>
          </Card>
        </div>
      </div>
    </Section>
  );
}

// ═══════════════════════════════════════════════════════════════
// 5. CONSENT FORMS
// ═══════════════════════════════════════════════════════════════
export function ConsentView() {
  return (
    <Section title="✍️ Consent Form Builder" sub="Digital consents with e-signature, procedure-specific templates">
      <Grid cols={3} gap={10}>
        {[["General Treatment Consent","6 fields","All","1,240"],["Implant Surgical Consent","12 fields","D6010-D6050","342"],["Extraction Consent","8 fields","D7140-D7230","567"],["Orthodontic Agreement","15 fields","D8010-D8090","189"],["Endodontic Consent","10 fields","D3310-D3330","234"],["Sedation Consent","14 fields","D9220-D9243","156"],["HIPAA Privacy Notice","3 fields","All patients","3,105"],["Financial Agreement","5 fields","All patients","3,105"],["Whitening Consent","6 fields","D9972-D9975","98"],["Perio Surgery Consent","11 fields","D4210-D4274","78"]].map(([name,fields,proc,sigs],i) => (
          <Card key={i}>
            <div style={{fontSize:12,fontWeight:700,marginBottom:3}}>{name}</div>
            <div style={{fontSize:10,color:C.muted,marginBottom:6}}>{fields} · {proc} · {sigs} signatures</div>
            <div style={{display:"flex",gap:4}}><Badge color={C.success}>Active</Badge><Badge color={C.accent}>E-Sign</Badge></div>
          </Card>
        ))}
      </Grid>
    </Section>
  );
}

// ═══════════════════════════════════════════════════════════════
// 6. E-PRESCRIBING
// ═══════════════════════════════════════════════════════════════
export function ErxView() {
  return (
    <Section title="💊 E-Prescribing (eRx)" sub="EPCS-compliant, drug interaction checking, pharmacy integration">
      <Grid cols={3} style={{marginBottom:14}}>
        <Kpi icon="💊" label="Rx Sent Today" value="8" sub="6 antibiotics, 2 analgesics" color={C.accent} />
        <Kpi icon="⚠️" label="Interactions Flagged" value="2" sub="Both resolved" color={C.danger} />
        <Kpi icon="🏪" label="Pharmacies" value="47" sub="CVS, Walgreens, Rite Aid +" color={C.success} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>Recent Prescriptions</CardTitle>
          {[{p:"Margaret Sullivan",d:"Amoxicillin 500mg",s:"#21 — TID × 7d",ph:"CVS Auburn",alert:"⛔ Penicillin allergy — BLOCKED"},{p:"Robert Kim",d:"Ibuprofen 600mg",s:"#20 — Q6H PRN",ph:"Walgreens Roseville",alert:""},{p:"Michael Torres",d:"Clindamycin 300mg",s:"#28 — QID × 7d",ph:"CVS Auburn",alert:"⚠️ Check Warfarin interaction"},{p:"James Okafor",d:"Chlorhexidine 0.12%",s:"#1 — BID × 14d",ph:"Rite Aid Folsom",alert:""}].map((rx,i) => (
            <div key={i} style={{padding:"7px 0",borderBottom:i<3?`1px solid ${C.border}`:"none"}}>
              <Row><span style={{fontSize:12,fontWeight:700}}>{rx.p}</span><Badge color={C.success}>Sent</Badge></Row>
              <div style={{fontSize:10,color:C.muted}}>{rx.d} — {rx.s} · {rx.ph}</div>
              {rx.alert && <div style={{fontSize:10,color:C.danger,fontWeight:700,marginTop:2}}>{rx.alert}</div>}
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>🤖 AI Drug Interaction Engine</CardTitle>
          <Alert color={C.danger} icon="⛔" title="BLOCKED: Margaret Sullivan — Penicillin Allergy">Amoxicillin is penicillin-class. Auto-substituted: <strong>Clindamycin 300mg QID ×7d</strong> or <strong>Azithromycin 500mg then 250mg ×4d</strong>.</Alert>
          <Alert color={C.warning} icon="⚠️" title="WARNING: Michael Torres — Warfarin + Clindamycin">May increase INR. Notify cardiologist, INR check Day 3-5, reduce Warfarin if INR &gt;3.5. Documented.</Alert>
        </Card>
      </Grid>
    </Section>
  );
}

// ═══════════════════════════════════════════════════════════════
// 7. AI CLINICAL DECISION SUPPORT
// ═══════════════════════════════════════════════════════════════
export function AiClinicalView() {
  return (
    <Section title="🧠 AI Clinical Decision Support" sub="Drug interactions, contraindications, risk assessments, protocol recommendations">
      <Grid cols={2}>
        <Card>
          <CardTitle>⚠️ Active Patient Alerts</CardTitle>
          {[{p:"Margaret Sullivan",alert:"Bisphosphonate use — implant healing risk",sev:"high",action:"Monitor osseointegration. Consider BRONJ risk. Document consent.",c:C.danger},{p:"Michael Torres",alert:"Warfarin + upcoming implant surgery",sev:"high",action:"Contact cardiologist for INR. Target <2.5 pre-surgery. Hemostatic agents ready.",c:C.danger},{p:"James Okafor",alert:"Type 2 Diabetes — A1C check recommended",sev:"med",action:"Request A1C from PCP. If >8%, delay elective procedures.",c:C.warning},{p:"Diana Patel",alert:"Latex allergy — ensure latex-free supplies",sev:"med",action:"Flag appointments. Nitrile gloves, latex-free prophy cups.",c:C.warning},{p:"Sarah Chen",alert:"New patient — no medical history on file",sev:"low",action:"Intake forms pending. Do not treat until reviewed.",c:C.accent}].map((a,i) => (
            <Alert key={i} color={a.c} icon="" title={<>{a.p} <Badge color={a.c}>{a.sev}</Badge></>}><strong style={{color:a.c}}>{a.alert}</strong><br/>{a.action}</Alert>
          ))}
        </Card>
        <Card>
          <CardTitle>🧠 AI Protocol Recommendations</CardTitle>
          {[{t:"Pre-Surgical Antibiotic Protocol",d:"AHA guidelines: prosthetic valves, endocarditis history → Amoxicillin 2g PO 30-60 min pre-op (Clindamycin 600mg if allergy).",icon:"💊"},{t:"Perio-Systemic Risk Assessment",d:"Cross-references: diabetes, CVD, pregnancy, immunosuppression. Auto-adjusts recall intervals.",icon:"🔗"},{t:"Radiograph Interval Guidelines",d:"ADA/FDA: new pts need FMX/pano+BWX. Recall BWX every 6-18mo based on caries risk. CBCT when 2D insufficient.",icon:"📸"},{t:"Emergency Protocol Auto-Activation",d:"Notes mentioning syncope, chest pain, allergic reaction → auto-pulls emergency protocol card with step-by-step.",icon:"🚨"}].map((p,i) => (
            <div key={i} style={{padding:"8px 0",borderBottom:i<3?`1px solid ${C.border}`:"none"}}>
              <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:3}}><span style={{fontSize:14}}>{p.icon}</span><span style={{fontSize:11,fontWeight:800}}>{p.t}</span></div>
              <div style={{fontSize:10,color:"#7A8298",lineHeight:1.5}}>{p.d}</div>
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}
