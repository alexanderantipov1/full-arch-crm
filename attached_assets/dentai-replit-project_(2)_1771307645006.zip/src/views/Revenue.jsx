import React from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Row, Grid, Alert } from "../ui";

// ═══ 16. REVENUE CYCLE COMMAND CENTER ═══
export function RcmView() {
  return (
    <Section title="🎛️ Revenue Cycle Command Center" sub="Real-time pipeline from verification → payment — entire revenue cycle at a glance">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📋" label="Claims MTD" value="847" sub="94.2% first-pass rate" color={C.accent} />
        <Kpi icon="💰" label="Collections MTD" value="$198,240" sub="99.5% of net production" color={C.emerald} />
        <Kpi icon="⏱️" label="Days in A/R" value="18.4" sub="↓ from 32 days" color={C.success} />
        <Kpi icon="🔀" label="Cross-Coded" value="34" sub="$28,400 medical revenue" color={C.purple} />
      </Grid>
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📄" label="Necessity Letters" value="18" sub="91% approval rate" color={C.indigo} />
        <Kpi icon="⚔️" label="Open Denials" value="$12,840" sub="68% overturn rate" color={C.warning} />
        <Kpi icon="🎤" label="Voice Notes" value="24" sub="6.8 hrs saved today" color={C.cyan} />
        <Kpi icon="🏦" label="Payer Connections" value="340+" sub="All major payers" color={C.teal} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>🔴 Live Revenue Activity</CardTitle>
          {[["2:42 PM","✅ Claim D2740 #3 — Margaret Sullivan auto-submitted to Delta","$1,280",C.success],["2:38 PM","🔍 Insurance verified — Robert Kim (Cigna PPO) implant benefits confirmed","—",C.accent],["2:31 PM","🔀 Cross-coded: Sleep appliance D5988 → G47.33 → E0486 for medical billing","$2,400",C.purple],["2:24 PM","📄 Medical necessity letter generated for SRP D4341 — James Okafor","—",C.indigo],["2:18 PM","⚔️ Appeal auto-submitted: Denied crown D2740 — MetLife — clinical narrative attached","$1,280",C.warning],["2:10 PM","🎤 Voice note → SOAP → CDT auto-coded: Dr. Chen — Michael Torres implant follow-up","—",C.cyan],["1:55 PM","💰 ERA auto-posted: Cigna batch $8,420 — 12 claims reconciled","$8,420",C.emerald]].map(([time,action,amt,color],i) => (
            <div key={i} style={{padding:"7px 10px",background:`${color}04`,borderLeft:`2px solid ${color}30`,borderRadius:"0 8px 8px 0",marginBottom:5}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:10,color:C.muted}}>{time}</span>
                {amt !== "—" && <span style={{fontSize:11,fontWeight:800,color,fontFamily:"'JetBrains Mono'"}}>{amt}</span>}
              </div>
              <div style={{fontSize:10,color:"#8892A8",marginTop:2}}>{action}</div>
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>📊 Engine Performance</CardTitle>
          {[["Claim Accuracy","97.8%",97.8,C.success],["Verification Speed","4.2 sec",95,C.accent],["Cross-Code Match","89%",89,C.purple],["Necessity Approval","91%",91,C.indigo],["Appeal Overturn","68%",68,C.warning],["Voice-to-Code","98.4%",98.4,C.cyan],["ERA Auto-Post","96%",96,C.teal],["First-Pass Rate","94.2%",94.2,C.emerald]].map(([label,val,pct,color],i) => (
            <div key={i} style={{marginBottom:8}}>
              <Row><span style={{fontSize:11}}>{label}</span><span style={{fontSize:11,fontWeight:700,color,fontFamily:"'JetBrains Mono'"}}>{val}</span></Row>
              <Pbar v={pct} color={color} h={4} />
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 17. AI INSURANCE VERIFICATION ═══
export function VerifyView() {
  return (
    <Section title="🔍 AI Insurance Verification Engine" sub="Real-time eligibility, benefits breakdown, auto-estimate — replaces DentalRobot + Vyne">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🔍" label="Verified Today" value="48" sub="Tomorrow's schedule" color={C.accent} />
        <Kpi icon="⚡" label="Avg Speed" value="4.2 sec" sub="vs 12 min manual" color={C.success} />
        <Kpi icon="✅" label="Accuracy" value="98.6%" color={C.emerald} />
        <Kpi icon="🏦" label="Payers Connected" value="340+" color={C.teal} />
      </Grid>
      <Card>
        <CardTitle>🔍 Tomorrow's Verification Results</CardTitle>
        {[["Robert Kim","Cigna PPO","Active","50% major, $2K max, $1,450 remaining","✓",C.success],["Margaret Sullivan","Delta Premier","Active","80% basic, 50% major, $1,800 remaining","✓",C.success],["Diana Patel","MetLife PPO","Active","$2K ortho lifetime, $800 remaining","⚠",C.warning],["James Okafor","Aetna DMO","Active","100% prev, 80% basic, 50% major","✓",C.success],["New — Garcia","Delta PPO","Active","100% prev, 80% basic, 50% major, $2K max","✓",C.success],["Tom Davis","BCBS FEP","Active","50% implant, $2.5K max, $400 remaining","⚠",C.warning]].map(([p,plan,st,benefits,check,color],i) => (
          <div key={i} style={{padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
            <Row><span style={{fontSize:12,fontWeight:700}}>{p}</span><div style={{display:"flex",gap:5}}><Badge color={C.success}>{st}</Badge><Badge color={color}>{check}</Badge></div></Row>
            <div style={{fontSize:10,color:C.muted}}>{plan} — {benefits}</div>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 18. AI CLAIMS ENGINE ═══
export function ClaimsView() {
  return (
    <Section title="📋 AI Claims Processing Engine" sub="Auto-code from notes, pre-submit scrubbing, ERA auto-posting">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📋" label="Submitted Today" value="34" sub="$42,800 total" color={C.accent} />
        <Kpi icon="🔧" label="Pre-Scrub Catches" value="7" sub="All auto-corrected" color={C.warning} />
        <Kpi icon="✅" label="Clean Claim Rate" value="97.1%" color={C.success} />
        <Kpi icon="💰" label="ERA Posted" value="$38,200" sub="Auto-reconciled" color={C.emerald} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>📋 Claims Queue</CardTitle>
          {[["Margaret Sullivan","D2740 Crown #3","$1,280","Delta Premier","submitted",C.accent],["Robert Kim","D0367 CBCT","$250","Cigna PPO","submitted",C.accent],["James Okafor","D4910 Perio Maint","$180","Aetna DMO","pending",C.warning],["Diana Patel","D8040 Ortho Comprehensive","$280","MetLife","pre-auth",C.purple],["Michael Torres","D2950+D2740 #17","$1,620","UHC","scrubbing",C.orange]].map(([p,proc,fee,payer,st,color],i) => (
            <div key={i} style={{padding:"7px 0",borderBottom:`1px solid ${C.border}`}}>
              <Row><span style={{fontSize:11,fontWeight:700}}>{p}</span><Badge color={color}>{st}</Badge></Row>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.muted}}><span>{proc} · {payer}</span><span style={{fontWeight:700,color:C.text,fontFamily:"'JetBrains Mono'"}}>{fee}</span></div>
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>🔧 AI Pre-Scrub Catches</CardTitle>
          {[["Missing tooth # on D2740","Auto-added from chart",C.warning],["D1110 frequency violation (Cigna)","Changed to D4910 — eligible",C.danger],["D2950 bundling risk","Attached narrative justification",C.warning],["Pre-auth required D8040","Auto-submitted to MetLife",C.purple],["Missing X-ray attachment D2740","Auto-attached PA from chart",C.warning]].map(([issue,fix,color],i) => (
            <Alert key={i} color={color} icon="🔧" title={issue}>{fix}</Alert>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 19. CDT-TO-CPT CROSS-CODING ═══
export function CrossCodeView() {
  return (
    <Section title="🔀 CDT-to-CPT Cross-Coding Engine" sub="Auto-detect medical billing opportunities — replaces Nexus">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🔀" label="Cross-Coded MTD" value="34" sub="$28,400 medical revenue" color={C.purple} />
        <Kpi icon="💰" label="Avg Per Patient" value="$835" sub="Additional revenue" color={C.emerald} />
        <Kpi icon="✅" label="Approval Rate" value="78%" color={C.success} />
        <Kpi icon="📋" label="CMS-1500 Generated" value="34" color={C.accent} />
      </Grid>
      <Card>
        <CardTitle>🔀 Cross-Coding Opportunities</CardTitle>
        {[["Sleep Apnea Appliance","D5988","G47.33","E0486","$2,400","$1,680","approved",C.success],["TMJ Splint Therapy","D7880","M26.60","21085","$1,800","$1,260","approved",C.success],["Oral Biopsy","D7286","K13.1","40808","$450","$380","pending",C.warning],["Bone Graft (Implant)","D7953","M27.8","21210","$1,200","$840","submitted",C.accent],["CBCT — Pathology Eval","D0367","Z13.89","70553","$250","$220","approved",C.success]].map(([proc,cdt,icd,cpt,dental,medical,st,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr 60px 65px 55px 70px 70px 75px",padding:"8px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{proc}</span>
            <span style={{fontFamily:"'JetBrains Mono'",color:C.accent}}>{cdt}</span>
            <span style={{fontFamily:"'JetBrains Mono'",color:C.orange}}>{icd}</span>
            <span style={{fontFamily:"'JetBrains Mono'",color:C.purple}}>{cpt}</span>
            <span style={{fontFamily:"'JetBrains Mono'"}}>{dental}</span>
            <span style={{fontFamily:"'JetBrains Mono'",color:C.emerald,fontWeight:700}}>{medical}</span>
            <Badge color={color}>{st}</Badge>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 20. AI NECESSITY LETTERS ═══
export function NecessityView() {
  return (
    <Section title="📄 AI Medical Necessity Letter Generator" sub="One-click from chart data — replaces BastionGPT">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="📄" label="Letters MTD" value="18" sub="12 sec avg generation" color={C.indigo} />
        <Kpi icon="✅" label="Approval Rate" value="91%" sub="vs 64% manual" color={C.success} />
        <Kpi icon="💰" label="Revenue Recovered" value="$42,800" color={C.emerald} />
        <Kpi icon="📊" label="Data Sources" value="6" sub="Notes, X-ray, perio, meds, hx, labs" color={C.accent} />
      </Grid>
      <Card>
        <CardTitle>📄 Recent Necessity Letters</CardTitle>
        {[["James Okafor","D4341 SRP — All Quads","Perio probing 4-7mm, 18% BOP, Stage III","Delta","approved","$820",C.success],["Margaret Sullivan","D2740 Crown #3","Fracture line visible, >50% tooth structure loss","MetLife","approved","$1,280",C.success],["Robert Kim","D6010 Implant #14","Missing tooth, bone sufficient per CBCT, adjacent teeth healthy","Cigna","pending","$2,200",C.warning],["Tom Davis","D6010-D6065 Full Arch","Complete edentulism, CBCT bone eval, medical necessity for function","BCBS","submitted","$24,800",C.accent],["Diana Patel","D8080 Comprehensive Ortho","Class II div 1 malocclusion, TMJ symptoms, functional impairment","MetLife","approved","$5,500",C.success]].map(([p,proc,evidence,payer,st,val,color],i) => (
          <div key={i} style={{padding:"8px 10px",borderLeft:`3px solid ${color}30`,borderRadius:"0 8px 8px 0",marginBottom:6,background:`${color}03`}}>
            <Row><span style={{fontSize:11,fontWeight:700}}>{p}</span><div style={{display:"flex",gap:4}}><Badge color={color}>{st}</Badge><span style={{fontSize:11,fontWeight:800,color:C.emerald,fontFamily:"'JetBrains Mono'"}}>{val}</span></div></Row>
            <div style={{fontSize:10,color:C.muted}}>{proc} · {payer}</div>
            <div style={{fontSize:10,color:"#7A8298",marginTop:2}}>📋 {evidence}</div>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 21. DENIAL MANAGEMENT ═══
export function DenialsView() {
  return (
    <Section title="⚔️ AI Denial Management & Appeals" sub="Root cause analysis → auto-appeal with evidence — replaces DataRovers + WhiteSpace">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="⚔️" label="Open Denials" value="23" sub="$12,840 at risk" color={C.danger} />
        <Kpi icon="🤖" label="Auto-Appealed" value="18" sub="78% automated" color={C.accent} />
        <Kpi icon="✅" label="Overturn Rate" value="68%" sub="vs 32% industry" color={C.success} />
        <Kpi icon="💰" label="Recovered MTD" value="$34,200" color={C.emerald} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>⚔️ Active Denials</CardTitle>
          {[["Margaret Sullivan","D2740 Crown #3","MetLife","Missing documentation","Appeal sent — narrative + X-ray attached","$1,280",C.warning],["Robert Kim","D0367 CBCT","Cigna","Not medically necessary","Appeal + medical necessity letter auto-generated","$250",C.warning],["Diana Patel","D8080 Ortho","MetLife","Frequency limitation","Appealing — prior auth was approved","$5,500",C.danger],["Tom Davis","D6010 Implant","BCBS","Pre-auth required","Pre-auth submitted retroactively + appeal","$2,200",C.warning]].map(([p,proc,payer,reason,action,val,color],i) => (
            <div key={i} style={{padding:"8px 10px",borderLeft:`3px solid ${color}`,borderRadius:"0 8px 8px 0",marginBottom:6,background:`${color}04`}}>
              <Row><span style={{fontSize:11,fontWeight:700}}>{p}</span><span style={{fontWeight:800,color:C.danger,fontFamily:"'JetBrains Mono'",fontSize:11}}>{val}</span></Row>
              <div style={{fontSize:10,color:C.muted}}>{proc} · {payer} · Reason: <span style={{color:C.danger}}>{reason}</span></div>
              <div style={{fontSize:10,color:C.success,marginTop:2}}>🤖 {action}</div>
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>📊 Denial Root Cause Analysis</CardTitle>
          {[["Missing documentation",35,C.danger],["Frequency limitations",22,C.warning],["Medical necessity",17,C.orange],["Pre-auth required",13,C.purple],["Not covered → cross-code",9,C.accent],["Coding errors",4,C.teal]].map(([reason,pct,color],i) => (
            <div key={i} style={{marginBottom:7}}>
              <Row><span style={{fontSize:11}}>{reason}</span><span style={{fontSize:11,fontWeight:700,color,fontFamily:"'JetBrains Mono'"}}>{pct}%</span></Row>
              <Pbar v={pct} color={color} h={4} />
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}
