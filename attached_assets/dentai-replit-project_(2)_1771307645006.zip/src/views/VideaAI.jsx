import { useState } from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Grid, Alert } from "../ui";

// ═══════════════════════════════════════════════════════════════════
// DENTAI VIDEA-LEVEL AI MODULE — 8 Sub-Tabs, 34+ Pathology Detections
// Matches & exceeds: ClinicalAI, WorkflowAI, EnterpriseAI, ClaimsAI
// ═══════════════════════════════════════════════════════════════════

const SUB_TABS = [
  { id: "clinical", label: "ClinicalAI", icon: "🔬", desc: "34+ Pathology Detections" },
  { id: "patient", label: "Patient View", icon: "🖥️", desc: "Chairside Education" },
  { id: "ortho", label: "OrthoAI", icon: "🦷", desc: "Aligner Candidates" },
  { id: "implant", label: "ImplantAI", icon: "🔩", desc: "Implant Candidates" },
  { id: "voice", label: "Voice Notes", icon: "🎤", desc: "Ambient Scribe" },
  { id: "claims", label: "ClaimsAI", icon: "📋", desc: "Auto Attachments" },
  { id: "insights", label: "InsightsAI", icon: "📊", desc: "Enterprise Analytics" },
  { id: "impact", label: "Impact Panel", icon: "💰", desc: "Revenue Attribution" },
];

// ═══ 34 PATHOLOGY DETECTION CATEGORIES ═══
const PATHOLOGY_CATEGORIES = [
  // Caries (8)
  { id: "C1", name: "Interproximal Caries — Early", group: "Caries", icon: "🔴", severity: "early", color: "#F59E0B" },
  { id: "C2", name: "Interproximal Caries — Moderate", group: "Caries", icon: "🔴", severity: "moderate", color: "#EA580C" },
  { id: "C3", name: "Interproximal Caries — Advanced", group: "Caries", icon: "🔴", severity: "advanced", color: "#DC2626" },
  { id: "C4", name: "Occlusal Caries", group: "Caries", icon: "🔴", severity: "variable", color: "#EF4444" },
  { id: "C5", name: "Buccal / Lingual Caries", group: "Caries", icon: "🔴", severity: "variable", color: "#F97316" },
  { id: "C6", name: "Root Caries", group: "Caries", icon: "🔴", severity: "moderate", color: "#DC2626" },
  { id: "C7", name: "Recurrent / Secondary Caries", group: "Caries", icon: "🔴", severity: "moderate", color: "#B91C1C" },
  { id: "C8", name: "Pediatric Primary Tooth Caries", group: "Caries", icon: "🔴", severity: "variable", color: "#F59E0B" },
  // Periodontal (6)
  { id: "P1", name: "Horizontal Bone Loss", group: "Periodontal", icon: "🟠", severity: "moderate", color: "#7C3AED" },
  { id: "P2", name: "Vertical / Angular Bone Loss", group: "Periodontal", icon: "🟠", severity: "severe", color: "#6D28D9" },
  { id: "P3", name: "Furcation Involvement", group: "Periodontal", icon: "🟠", severity: "moderate", color: "#8B5CF6" },
  { id: "P4", name: "Calculus (Supragingival)", group: "Periodontal", icon: "🟠", severity: "mild", color: "#A78BFA" },
  { id: "P5", name: "Calculus (Subgingival)", group: "Periodontal", icon: "🟠", severity: "moderate", color: "#7C3AED" },
  { id: "P6", name: "Widened PDL Space", group: "Periodontal", icon: "🟠", severity: "variable", color: "#6D28D9" },
  // Endodontic (4)
  { id: "E1", name: "Periapical Radiolucency", group: "Endodontic", icon: "🟡", severity: "needs eval", color: "#0891B2" },
  { id: "E2", name: "Pulp Calcification", group: "Endodontic", icon: "🟡", severity: "mild", color: "#06B6D4" },
  { id: "E3", name: "Internal Resorption", group: "Endodontic", icon: "🟡", severity: "severe", color: "#0E7490" },
  { id: "E4", name: "External Root Resorption", group: "Endodontic", icon: "🟡", severity: "moderate", color: "#155E75" },
  // Restorative (5)
  { id: "R1", name: "Defective / Open Margins", group: "Restorative", icon: "🔵", severity: "moderate", color: "#2563EB" },
  { id: "R2", name: "Fractured Restoration", group: "Restorative", icon: "🔵", severity: "moderate", color: "#1D4ED8" },
  { id: "R3", name: "Crown Margin Gap", group: "Restorative", icon: "🔵", severity: "mild", color: "#3B82F6" },
  { id: "R4", name: "Overhang Restoration", group: "Restorative", icon: "🔵", severity: "mild", color: "#60A5FA" },
  { id: "R5", name: "Missing Restoration", group: "Restorative", icon: "🔵", severity: "needs eval", color: "#2563EB" },
  // Structural (5)
  { id: "S1", name: "Root Fracture", group: "Structural", icon: "⚫", severity: "severe", color: "#DC2626" },
  { id: "S2", name: "Crown Fracture", group: "Structural", icon: "⚫", severity: "moderate", color: "#EF4444" },
  { id: "S3", name: "Missing Tooth", group: "Structural", icon: "⚫", severity: "treatment", color: "#6B7280" },
  { id: "S4", name: "Impacted Tooth", group: "Structural", icon: "⚫", severity: "needs eval", color: "#4B5563" },
  { id: "S5", name: "Supernumerary Tooth", group: "Structural", icon: "⚫", severity: "needs eval", color: "#374151" },
  // Other (6)
  { id: "O1", name: "Sinus Proximity / Communication", group: "Other", icon: "🟤", severity: "surgical", color: "#0D9488" },
  { id: "O2", name: "Retained Root Tip", group: "Other", icon: "🟤", severity: "moderate", color: "#14B8A6" },
  { id: "O3", name: "Cyst-like Lesion", group: "Other", icon: "🟤", severity: "needs eval", color: "#0F766E" },
  { id: "O4", name: "Implant Bone Integration", group: "Other", icon: "🟤", severity: "assessment", color: "#059669" },
  { id: "O5", name: "Nerve Canal Proximity", group: "Other", icon: "🟤", severity: "surgical", color: "#047857" },
  { id: "O6", name: "Pediatric Development Assessment", group: "Other", icon: "🟤", severity: "monitoring", color: "#10B981" },
];

// ═══ SHARED SUB-COMPONENTS ═══
const SubTab = ({ tabs, active, onChange }) => (
  <div style={{ display: "flex", gap: 4, padding: "4px 5px", background: "#0D0F18", borderRadius: 12, marginBottom: 16, overflowX: "auto", flexWrap: "wrap" }}>
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)} style={{
        display: "flex", alignItems: "center", gap: 6,
        padding: "8px 14px", borderRadius: 9, border: "none",
        background: active === t.id ? `${C.accent}18` : "transparent",
        cursor: "pointer", transition: "0.15s", whiteSpace: "nowrap",
        borderBottom: active === t.id ? `2px solid ${C.accent}` : "2px solid transparent",
      }}>
        <span style={{ fontSize: 13 }}>{t.icon}</span>
        <div style={{ textAlign: "left" }}>
          <div style={{ fontSize: 11, fontWeight: active === t.id ? 800 : 600, color: active === t.id ? C.accent : C.sideText }}>{t.label}</div>
          <div style={{ fontSize: 8, color: "#475569", letterSpacing: 0.5 }}>{t.desc}</div>
        </div>
      </button>
    ))}
  </div>
);

const HeatBox = ({ v, max = 100, label, color }) => {
  const pct = v / max;
  const bg = pct > 0.8 ? "#DC262620" : pct > 0.5 ? "#F59E0B18" : "#10B98112";
  const fg = pct > 0.8 ? "#DC2626" : pct > 0.5 ? "#F59E0B" : "#10B981";
  return (
    <div style={{ background: bg, borderRadius: 8, padding: "8px 10px", textAlign: "center", border: `1px solid ${fg}20` }}>
      <div style={{ fontSize: 18, fontWeight: 900, color: color || fg, fontFamily: "'JetBrains Mono'" }}>{v}%</div>
      <div style={{ fontSize: 9, color: C.muted, fontWeight: 600, marginTop: 2 }}>{label}</div>
    </div>
  );
};

const ToothMap = ({ findings }) => {
  const upperTeeth = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16];
  const lowerTeeth = [32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17];
  const findingMap = {};
  findings.forEach(f => { findingMap[f.tooth] = f; });

  const renderRow = (teeth) => (
    <div style={{ display: "flex", gap: 2, justifyContent: "center" }}>
      {teeth.map(t => {
        const f = findingMap[t];
        const bg = f ? (f.severity === "severe" ? "#DC262630" : f.severity === "moderate" ? "#F59E0B25" : f.severity === "early" ? "#10B98118" : "#3B82F618") : "#1A1D2A";
        const border = f ? (f.severity === "severe" ? "#DC2626" : f.severity === "moderate" ? "#F59E0B" : f.severity === "early" ? "#10B981" : "#3B82F6") : "#2A2E3E";
        return (
          <div key={t} style={{
            width: 32, height: 36, borderRadius: 6, background: bg, border: `1.5px solid ${border}`,
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            cursor: f ? "pointer" : "default", transition: "0.15s", position: "relative",
          }}>
            <div style={{ fontSize: 10, fontWeight: 800, color: f ? border : "#3A3F50" }}>{t}</div>
            {f && <div style={{ fontSize: 7, color: border, fontWeight: 700, marginTop: 1 }}>{f.count}</div>}
            {f && f.count > 1 && (
              <div style={{ position: "absolute", top: -4, right: -4, width: 12, height: 12, borderRadius: "50%", background: border, color: "#FFF", fontSize: 7, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center" }}>{f.count}</div>
            )}
          </div>
        );
      })}
    </div>
  );

  return (
    <div style={{ background: "#0D0F18", borderRadius: 12, padding: "16px 20px" }}>
      <div style={{ fontSize: 9, color: "#475569", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6, textAlign: "center" }}>MAXILLARY</div>
      {renderRow(upperTeeth)}
      <div style={{ height: 1, background: "#1E2130", margin: "8px 0" }} />
      {renderRow(lowerTeeth)}
      <div style={{ fontSize: 9, color: "#475569", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginTop: 6, textAlign: "center" }}>MANDIBULAR</div>
    </div>
  );
};

// ═══════════════════════════════════════
// 1. CLINICAL AI — 34+ Pathology Detections
// ═══════════════════════════════════════
function ClinicalAIPanel() {
  const [selectedGroup, setSelectedGroup] = useState("All");
  const groups = ["All", ...new Set(PATHOLOGY_CATEGORIES.map(p => p.group))];

  const patientFindings = [
    { tooth: 3, finding: "Interproximal Caries — Moderate", id: "C2", confidence: 94, severity: "moderate", cdtSuggest: "D2392" },
    { tooth: 5, finding: "Horizontal Bone Loss", id: "P1", confidence: 88, severity: "moderate", cdtSuggest: "D4341" },
    { tooth: 8, finding: "Crown Margin Gap", id: "R3", confidence: 82, severity: "mild", cdtSuggest: "D2740" },
    { tooth: 14, finding: "Periapical Radiolucency", id: "E1", confidence: 91, severity: "severe", cdtSuggest: "D3330" },
    { tooth: 14, finding: "Interproximal Caries — Advanced", id: "C3", confidence: 96, severity: "severe", cdtSuggest: "D2750" },
    { tooth: 19, finding: "Occlusal Caries", id: "C4", confidence: 87, severity: "moderate", cdtSuggest: "D2391" },
    { tooth: 19, finding: "Calculus (Subgingival)", id: "P5", confidence: 79, severity: "moderate", cdtSuggest: "D4341" },
    { tooth: 20, finding: "Defective / Open Margins", id: "R1", confidence: 85, severity: "moderate", cdtSuggest: "D2392" },
    { tooth: 30, finding: "Vertical / Angular Bone Loss", id: "P2", confidence: 92, severity: "severe", cdtSuggest: "D4260" },
    { tooth: 30, finding: "Furcation Involvement", id: "P3", confidence: 76, severity: "moderate", cdtSuggest: "D4263" },
    { tooth: 31, finding: "Root Caries", id: "C6", confidence: 84, severity: "moderate", cdtSuggest: "D2394" },
  ];

  const toothFindings = {};
  patientFindings.forEach(f => {
    if (!toothFindings[f.tooth]) toothFindings[f.tooth] = { tooth: f.tooth, count: 0, severity: "mild" };
    toothFindings[f.tooth].count++;
    if (f.severity === "severe") toothFindings[f.tooth].severity = "severe";
    else if (f.severity === "moderate" && toothFindings[f.tooth].severity !== "severe") toothFindings[f.tooth].severity = "moderate";
  });

  return (
    <>
      <Grid cols="repeat(auto-fit, minmax(150px, 1fr))">
        <Kpi icon="🔬" label="AI Detections" value="11" sub="Across 8 teeth" color="#DC2626" />
        <Kpi icon="🦷" label="Teeth Affected" value="8 / 28" sub="28.6% of dentition" color={C.accent} />
        <Kpi icon="🎯" label="Avg Confidence" value="86.7%" sub="Range: 76—96%" color="#7C3AED" />
        <Kpi icon="⚡" label="Analysis Time" value="0.8s" sub="Per image" color={C.success} />
        <Kpi icon="📸" label="Images Analyzed" value="6" sub="4 BWX + 2 PA" color={C.cyan} />
        <Kpi icon="💰" label="Treatment Value" value="$8,420" sub="Detected opportunities" color="#EA580C" />
      </Grid>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14, marginTop: 14 }}>
        {/* Main Viewer */}
        <div>
          <Card>
            <div style={{ background: "#070810", borderRadius: 10, padding: "16px", marginBottom: 12, position: "relative" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                <div style={{ display: "flex", gap: 4 }}>
                  <Badge color={C.accent} solid>BWX — Right Side</Badge>
                  <Badge color={C.success} solid>2026-02-15</Badge>
                  <Badge color="#7C3AED" solid>Margaret Sullivan</Badge>
                </div>
                <div style={{ display: "flex", gap: 4 }}>
                  <Badge color="#DC2626" solid>🤖 5 AI Findings</Badge>
                </div>
              </div>

              {/* Simulated X-ray viewer with annotation overlay */}
              <div style={{ width: "100%", height: 200, background: "linear-gradient(135deg, #0a0a12, #12141f)", borderRadius: 8, border: "1px solid #1E2130", position: "relative", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
                {/* Tooth silhouettes */}
                {[0,1,2,3].map(i => (
                  <div key={i} style={{ width: 48, height: 120, margin: "0 6px", background: "linear-gradient(180deg, #1a1c28 0%, #15171f 100%)", borderRadius: "8px 8px 4px 4px", border: "1px solid #252838", position: "relative" }}>
                    {i === 1 && <div style={{ position: "absolute", top: 30, left: 8, width: 32, height: 18, borderRadius: 4, border: "2px solid #DC2626", background: "#DC262615", animation: "blink 2s infinite" }} />}
                    {i === 3 && <div style={{ position: "absolute", bottom: 10, left: 6, width: 36, height: 14, borderRadius: 3, border: "2px solid #F59E0B", background: "#F59E0B12", animation: "blink 2s infinite" }} />}
                    {i === 0 && <div style={{ position: "absolute", top: 45, right: 0, width: 16, height: 22, borderRadius: "0 4px 4px 0", border: "2px solid #7C3AED", background: "#7C3AED12" }} />}
                  </div>
                ))}

                {/* AI Annotation callouts */}
                <div style={{ position: "absolute", top: 12, left: 12, background: "#DC262620", borderRadius: 8, padding: "6px 10px", border: "1px solid #DC2626", backdropFilter: "blur(4px)" }}>
                  <div style={{ fontSize: 9, fontWeight: 800, color: "#DC2626" }}>CARIES — #14 mesial</div>
                  <div style={{ fontSize: 8, color: "#F87171" }}>96% confidence • Advanced</div>
                </div>
                <div style={{ position: "absolute", bottom: 12, right: 12, background: "#F59E0B18", borderRadius: 8, padding: "6px 10px", border: "1px solid #F59E0B" }}>
                  <div style={{ fontSize: 9, fontWeight: 800, color: "#F59E0B" }}>BONE LOSS — #30 distal</div>
                  <div style={{ fontSize: 8, color: "#FBBF24" }}>92% confidence • Vertical</div>
                </div>
                <div style={{ position: "absolute", top: 12, right: 12, background: "#7C3AED15", borderRadius: 8, padding: "6px 10px", border: "1px solid #7C3AED" }}>
                  <div style={{ fontSize: 9, fontWeight: 800, color: "#7C3AED" }}>PERIAPICAL — #14</div>
                  <div style={{ fontSize: 8, color: "#A78BFA" }}>91% confidence</div>
                </div>
              </div>

              {/* Viewer toolbar */}
              <div style={{ display: "flex", gap: 4, marginTop: 8 }}>
                {["Brightness", "Contrast", "Invert", "Zoom", "Measure", "Annotate", "Compare", "AI Toggle", "Patient View"].map(t => (
                  <button key={t} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 6, padding: "5px 9px", color: t === "AI Toggle" ? C.accent : "#64748B", fontSize: 9, fontWeight: 600, cursor: "pointer" }}>{t}</button>
                ))}
              </div>
            </div>

            {/* Tooth Map */}
            <CardTitle>AI Detection Map — Full Mouth</CardTitle>
            <ToothMap findings={Object.values(toothFindings)} />
          </Card>
        </div>

        {/* Right Panel — Findings List */}
        <div>
          <Card>
            <CardTitle>🤖 AI Findings ({patientFindings.length})</CardTitle>
            <div style={{ maxHeight: 460, overflowY: "auto" }}>
              {patientFindings.map((f, i) => {
                const cat = PATHOLOGY_CATEGORIES.find(c => c.id === f.id);
                return (
                  <div key={i} style={{
                    padding: "10px 12px", marginBottom: 6,
                    background: f.severity === "severe" ? "#DC262608" : f.severity === "moderate" ? "#F59E0B06" : "#10B98105",
                    borderLeft: `3px solid ${f.severity === "severe" ? "#DC2626" : f.severity === "moderate" ? "#F59E0B" : "#10B981"}`,
                    borderRadius: "0 8px 8px 0",
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 3 }}>
                      <span style={{ fontSize: 11, fontWeight: 800 }}>#{f.tooth} — {f.finding}</span>
                      <Badge color={f.severity === "severe" ? "#DC2626" : f.severity === "moderate" ? "#F59E0B" : "#10B981"}>{f.severity}</Badge>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <Pbar v={f.confidence} color={cat?.color || C.accent} h={3} />
                      <span style={{ fontSize: 10, fontWeight: 800, color: cat?.color, fontFamily: "'JetBrains Mono'" }}>{f.confidence}%</span>
                    </div>
                    <div style={{ display: "flex", gap: 6, fontSize: 10, color: C.muted }}>
                      <span>CDT: <strong style={{ color: C.accent }}>{f.cdtSuggest}</strong></span>
                      <span>•</span>
                      <span>{cat?.group}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>

      {/* Detection Categories Coverage */}
      <Card style={{ marginTop: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <CardTitle>34 Pathology Detection Categories — AI Coverage</CardTitle>
          <div style={{ display: "flex", gap: 4 }}>
            {groups.map(g => (
              <button key={g} onClick={() => setSelectedGroup(g)} style={{
                background: selectedGroup === g ? `${C.accent}15` : "transparent",
                border: `1px solid ${selectedGroup === g ? C.accent : C.border}`, borderRadius: 6,
                padding: "3px 10px", fontSize: 10, fontWeight: 700,
                color: selectedGroup === g ? C.accent : C.muted, cursor: "pointer",
              }}>{g}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 6 }}>
          {PATHOLOGY_CATEGORIES.filter(p => selectedGroup === "All" || p.group === selectedGroup).map(p => (
            <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 10px", background: `${p.color}06`, borderRadius: 7, border: `1px solid ${p.color}12` }}>
              <span style={{ fontSize: 10, fontWeight: 800, color: p.color, fontFamily: "'JetBrains Mono'", minWidth: 24 }}>{p.id}</span>
              <span style={{ fontSize: 10, fontWeight: 600, flex: 1 }}>{p.name}</span>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.success }} />
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

// ═══════════════════════════════════════
// 2. PATIENT VIEW — Chairside Education
// ═══════════════════════════════════════
function PatientViewPanel() {
  return (
    <>
      <Alert color={C.accent}>
        <strong>Patient View</strong> transforms complex X-ray findings into clear, visual explanations patients can see and understand — driving 22%+ higher treatment acceptance. Toggle between annotated and clean views chairside.
      </Alert>

      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="📈" label="Acceptance Lift" value="+22%" sub="With Patient View" color={C.success} />
        <Kpi icon="💰" label="Annual Revenue Add" value="$78K" sub="Per practice avg" color="#EA580C" />
        <Kpi icon="🤝" label="Patient Trust Score" value="94%" sub="Post-presentation survey" color="#7C3AED" />
        <Kpi icon="⏱️" label="Presentation Time" value="90 sec" sub="Avg per patient" color={C.accent} />
      </Grid>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
        {/* Annotated View */}
        <Card>
          <CardTitle>🔬 AI-Annotated View (Provider)</CardTitle>
          <div style={{ background: "#070810", borderRadius: 10, padding: "14px", minHeight: 220, position: "relative" }}>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", alignItems: "end", height: 160 }}>
              {[
                { tooth: 13, status: "healthy" }, { tooth: 14, status: "caries_advanced", label: "Advanced Caries" },
                { tooth: 15, status: "healthy" }, { tooth: 16, status: "bone_loss", label: "Bone Loss" },
              ].map((t, i) => (
                <div key={i} style={{ position: "relative", textAlign: "center" }}>
                  <div style={{
                    width: 48, height: t.status === "healthy" ? 100 : 110, borderRadius: "10px 10px 4px 4px",
                    background: t.status === "healthy" ? "#1a1c28" : t.status === "caries_advanced" ? "linear-gradient(180deg, #1a1c28, #2a1015)" : "linear-gradient(180deg, #1a1c28, #1a1520)",
                    border: `2px solid ${t.status === "healthy" ? "#252838" : t.status === "caries_advanced" ? "#DC2626" : "#7C3AED"}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}>
                    {t.status !== "healthy" && (
                      <div style={{
                        width: 24, height: 20, borderRadius: 4,
                        border: `2px dashed ${t.status === "caries_advanced" ? "#DC2626" : "#7C3AED"}`,
                        background: `${t.status === "caries_advanced" ? "#DC2626" : "#7C3AED"}15`,
                        animation: "blink 2s infinite",
                      }} />
                    )}
                  </div>
                  <div style={{ fontSize: 9, fontWeight: 700, color: t.status === "healthy" ? "#3A3F50" : "#F87171", marginTop: 4 }}>#{t.tooth}</div>
                  {t.label && <div style={{ fontSize: 8, color: t.status === "caries_advanced" ? "#DC2626" : "#7C3AED", fontWeight: 700 }}>{t.label}</div>}
                </div>
              ))}
            </div>
            <div style={{ position: "absolute", top: 8, left: 8 }}><Badge color="#DC2626" solid>AI ANNOTATED</Badge></div>
          </div>
        </Card>

        {/* Patient-Friendly View */}
        <Card>
          <CardTitle>🖥️ Patient Education View</CardTitle>
          <div style={{ background: "#070810", borderRadius: 10, padding: "14px", minHeight: 220, position: "relative" }}>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", alignItems: "end", height: 160 }}>
              {[
                { tooth: 13, color: "#10B981", label: "Healthy ✓" },
                { tooth: 14, color: "#DC2626", label: "Cavity Found", desc: "Needs crown" },
                { tooth: 15, color: "#10B981", label: "Healthy ✓" },
                { tooth: 16, color: "#F59E0B", label: "Gum Issue", desc: "Needs deep clean" },
              ].map((t, i) => (
                <div key={i} style={{ textAlign: "center" }}>
                  <div style={{
                    width: 52, height: 100, borderRadius: 12,
                    background: `${t.color}10`, border: `3px solid ${t.color}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 24,
                  }}>
                    {t.color === "#10B981" ? "✅" : t.color === "#DC2626" ? "⚠️" : "🟡"}
                  </div>
                  <div style={{ fontSize: 10, fontWeight: 800, color: t.color, marginTop: 4 }}>#{t.tooth}</div>
                  <div style={{ fontSize: 9, fontWeight: 700, color: t.color }}>{t.label}</div>
                  {t.desc && <div style={{ fontSize: 8, color: C.muted }}>{t.desc}</div>}
                </div>
              ))}
            </div>
            <div style={{ position: "absolute", top: 8, left: 8 }}><Badge color={C.success} solid>PATIENT VIEW</Badge></div>
          </div>
        </Card>
      </div>

      {/* Presentation Script */}
      <Card style={{ marginTop: 14 }}>
        <CardTitle>🗣️ AI-Generated Presentation Script</CardTitle>
        <div style={{ background: `${C.accent}05`, borderRadius: 10, padding: "14px 18px", border: `1px solid ${C.accent}12` }}>
          <div style={{ fontSize: 12, lineHeight: 1.7, color: "#CBD5E1" }}>
            <strong style={{ color: C.accent }}>"Mrs. Sullivan,</strong> I've reviewed your X-rays with our AI diagnostic assistant. Let me show you what we found. On <strong style={{ color: "#DC2626" }}>tooth #14 here</strong>, the AI detected an advanced cavity on the inner surface — you can see it highlighted in red. The AI is 96% confident about this finding. We'll need a crown to protect that tooth. Over on <strong style={{ color: "#7C3AED" }}>tooth #30</strong>, there's some bone loss around the roots that needs treatment with a deep cleaning. The good news is we caught both of these early enough that treatment will be straightforward. Would you like to see the treatment options and costs?"
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
          <button style={{ background: C.success, color: "#FFF", border: "none", borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>✓ Present to Patient</button>
          <button style={{ background: `${C.accent}10`, color: C.accent, border: `1px solid ${C.accent}20`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>📧 Email to Patient</button>
          <button style={{ background: `${C.card}`, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 600, cursor: "pointer", color: C.muted }}>🖨️ Print Report</button>
        </div>
      </Card>
    </>
  );
}

// ═══════════════════════════════════════
// 3. ORTHO AI — Aligner Candidate Identification
// ═══════════════════════════════════════
function OrthoAIPanel() {
  return (
    <>
      <Alert color="#7C3AED">
        <strong>OrthoAI</strong> analyzes routine radiographs to identify high-probability aligner candidates — practices see a 14% increase in aligner treatment plans within 30 days and 12x more 3D scans. Potential revenue lift: $100K–$175K/practice.
      </Alert>

      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="🦷" label="Aligner Candidates Found" value="18" sub="This month" color="#7C3AED" />
        <Kpi icon="📈" label="Scan Increase" value="12x" sub="Since OrthoAI launch" color={C.success} />
        <Kpi icon="💰" label="Revenue Opportunity" value="$142K" sub="Potential MTD" color="#EA580C" />
        <Kpi icon="✅" label="Conversion Rate" value="34%" sub="Candidate → Treatment" color={C.accent} />
        <Kpi icon="🎯" label="Avg Confidence" value="88%" sub="Candidate scoring" color="#0891B2" />
        <Kpi icon="📊" label="Plans Created" value="6" sub="From AI flags this week" color={C.teal} />
      </Grid>

      <Card style={{ marginTop: 14 }}>
        <CardTitle>🦷 AI-Flagged Aligner Candidates — Auto-Detected from X-Rays</CardTitle>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 10 }}>
          {[
            { patient: "Diana Patel", age: 28, score: 94, findings: ["Mild crowding #22-27", "Class I malocclusion", "Good bone support"], est: "$5,500", status: "In Treatment", priority: "active" },
            { patient: "Emma Rodriguez", age: 32, score: 91, findings: ["Moderate spacing #7-10", "Slight overjet", "Healthy periodontium"], est: "$4,800", status: "Accepted", priority: "high" },
            { patient: "Tyler Nguyen", age: 19, score: 88, findings: ["Mild rotation #6, #11", "Acceptable bone levels", "No restorations"], est: "$4,200", status: "Presented", priority: "high" },
            { patient: "Sarah Chen", age: 45, score: 82, findings: ["Relapse from prior ortho", "Mild crowding lower anterior", "Good candidate for refinement"], est: "$3,800", status: "New Flag", priority: "medium" },
            { patient: "Lisa Park", age: 24, score: 79, findings: ["Deep bite", "Mild crowding", "Needs perio clearance first"], est: "$5,200", status: "New Flag", priority: "medium" },
            { patient: "James Okafor", age: 38, score: 74, findings: ["Spacing #8-9 post-extraction", "Consider partial aligner", "Active perio — treat first"], est: "$3,200", status: "Deferred", priority: "low" },
          ].map((c, i) => (
            <div key={i} style={{ background: `${c.priority === "active" ? C.success : c.priority === "high" ? "#7C3AED" : c.priority === "medium" ? C.accent : C.muted}05`, border: `1px solid ${c.priority === "active" ? C.success : c.priority === "high" ? "#7C3AED" : c.priority === "medium" ? C.accent : C.muted}15`, borderRadius: 12, padding: "14px 16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 800 }}>{c.patient}</div>
                  <div style={{ fontSize: 10, color: C.muted }}>Age {c.age}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 18, fontWeight: 900, color: "#7C3AED", fontFamily: "'JetBrains Mono'" }}>{c.score}%</div>
                  <div style={{ fontSize: 8, color: C.muted }}>AI SCORE</div>
                </div>
              </div>
              {c.findings.map((f, fi) => (
                <div key={fi} style={{ fontSize: 10, color: "#94A3B8", padding: "2px 0", borderBottom: fi < c.findings.length - 1 ? `1px solid ${C.border}` : "none" }}>• {f}</div>
              ))}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
                <span style={{ fontSize: 12, fontWeight: 800, fontFamily: "'JetBrains Mono'" }}>{c.est}</span>
                <Badge color={c.status === "In Treatment" ? C.success : c.status === "Accepted" ? "#7C3AED" : c.status === "Presented" ? C.accent : c.status === "New Flag" ? "#F59E0B" : C.muted}>{c.status}</Badge>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

// ═══════════════════════════════════════
// 4. IMPLANT AI — Implant Candidate Identification
// ═══════════════════════════════════════
function ImplantAIPanel() {
  return (
    <>
      <Alert color={C.accent}>
        <strong>ImplantAI</strong> evaluates X-rays to flag potential implant candidates by identifying missing teeth, bone adequacy, and anatomical considerations. Embedded directly into the workflow — no extra steps required.
      </Alert>

      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="🔩" label="Implant Candidates" value="12" sub="Flagged this month" color={C.accent} />
        <Kpi icon="💰" label="Revenue Opportunity" value="$284K" sub="Potential implant revenue" color={C.success} />
        <Kpi icon="🦴" label="Bone Adequate" value="9/12" sub="75% immediate candidates" color="#0891B2" />
        <Kpi icon="📈" label="Consult Conversion" value="42%" sub="Flag → consult booked" color="#7C3AED" />
      </Grid>

      <Card style={{ marginTop: 14 }}>
        <CardTitle>🔩 AI-Flagged Implant Candidates</CardTitle>
        {[
          { patient: "Robert Kim", tooth: "#14", bone: "Adequate (12mm height)", sinus: "3mm clearance — no lift needed", score: 94, est: "$5,050", status: "Consult Booked", anatomy: "Favorable", risk: "Low" },
          { patient: "Margaret Sullivan", tooth: "#19", bone: "Moderate (9mm height)", sinus: "N/A — mandibular", score: 88, est: "$4,800", anatomy: "Favorable", status: "Presented", risk: "Low" },
          { patient: "Tom Davis", tooth: "#8, #9 (anterior)", bone: "Adequate — aesthetic zone", sinus: "N/A — anterior", score: 85, est: "$12,400", anatomy: "Narrow ridge — may need GBR", status: "Treatment Planning", risk: "Medium" },
          { patient: "Frank Morris", tooth: "#30", bone: "Limited (7mm) — graft recommended", sinus: "N/A", score: 72, est: "$6,200", anatomy: "IAN proximity 2mm", status: "New Flag", risk: "Medium" },
          { patient: "Karen Brown", tooth: "#3, #4", bone: "Adequate bilateral", sinus: "5mm clearance", score: 91, est: "$9,600", anatomy: "Favorable bilateral", status: "New Flag", risk: "Low" },
        ].map((c, i) => (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "1.2fr 60px 1fr 1fr 60px 80px 70px 80px", padding: "10px 0", borderBottom: `1px solid ${C.border}`, alignItems: "center", gap: 8 }}>
            <div style={{ fontSize: 12, fontWeight: 700 }}>{c.patient}</div>
            <span style={{ fontSize: 11, fontWeight: 800, color: C.accent, fontFamily: "'JetBrains Mono'" }}>{c.tooth}</span>
            <div style={{ fontSize: 10, color: C.muted }}>{c.bone}</div>
            <div style={{ fontSize: 10, color: C.muted }}>{c.anatomy}</div>
            <div style={{ fontSize: 14, fontWeight: 900, color: "#7C3AED", fontFamily: "'JetBrains Mono'" }}>{c.score}%</div>
            <span style={{ fontSize: 11, fontWeight: 700, fontFamily: "'JetBrains Mono'" }}>{c.est}</span>
            <Badge color={c.risk === "Low" ? C.success : "#F59E0B"}>{c.risk} Risk</Badge>
            <Badge color={c.status === "Treatment Planning" ? C.success : c.status === "Consult Booked" ? C.accent : c.status === "Presented" ? "#7C3AED" : "#F59E0B"}>{c.status}</Badge>
          </div>
        ))}
      </Card>
    </>
  );
}

// ═══════════════════════════════════════
// 5. VOICE NOTES — Ambient AI Scribe
// ═══════════════════════════════════════
function VoiceNotesPanel() {
  return (
    <>
      <Alert color="#0891B2">
        <strong>Voice Notes</strong> — the first ambient AI scribe purpose-built for dentistry. Turns chairside conversations into chart-ready clinical notes in seconds. Links diagnosis from imaging with documentation — no typing, no templates, no extra steps.
      </Alert>

      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="🎤" label="Notes Today" value="18" sub="4.2 min avg saved per note" color="#0891B2" />
        <Kpi icon="⏱️" label="Time Saved (MTD)" value="14.6 hrs" sub="$3,200 in provider time" color={C.success} />
        <Kpi icon="📋" label="Auto-Coded" value="97.8%" sub="CDT codes assigned" color="#7C3AED" />
        <Kpi icon="🔗" label="Imaging Linked" value="94%" sub="Notes linked to AI findings" color={C.accent} />
      </Grid>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
        {/* Live Recording */}
        <Card>
          <CardTitle>🎤 Live Ambient Recording</CardTitle>
          <div style={{ background: "#070810", borderRadius: 12, padding: "20px", textAlign: "center", marginBottom: 12 }}>
            <div style={{ width: 80, height: 80, borderRadius: "50%", background: "linear-gradient(135deg, #0891B2, #06B6D4)", margin: "0 auto 12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, boxShadow: "0 0 40px rgba(8,145,178,0.3)", animation: "blink 2s infinite" }}>🎤</div>
            <div style={{ fontSize: 14, fontWeight: 800, color: "#06B6D4", marginBottom: 4 }}>Listening...</div>
            <div style={{ fontSize: 11, color: C.muted }}>Dr. Chen • Op 3 • Margaret Sullivan</div>
            <div style={{ display: "flex", gap: 4, justifyContent: "center", marginTop: 12 }}>
              {[...Array(20)].map((_, i) => (
                <div key={i} style={{ width: 3, height: 8 + Math.random() * 20, background: `${C.accent}${Math.random() > 0.5 ? "60" : "30"}`, borderRadius: 2 }} />
              ))}
            </div>
          </div>

          <div style={{ background: `${C.accent}05`, borderRadius: 10, padding: "12px 14px", border: `1px solid ${C.accent}10`, marginBottom: 8 }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1, textTransform: "uppercase", marginBottom: 4 }}>LIVE TRANSCRIPT</div>
            <div style={{ fontSize: 11, color: "#94A3B8", lineHeight: 1.6 }}>
              <span style={{ color: "#06B6D4", fontWeight: 700 }}>Dr. Chen:</span> "...sensitivity is normal at this stage. The implant at fourteen is integrating well, I can see good bone contact on the CBCT. Let's plan for the final impression in about eight weeks..."
              <br/><span style={{ color: "#F59E0B", fontWeight: 700 }}>Patient:</span> "Okay, and should I keep taking ibuprofen?"
              <br/><span style={{ color: "#06B6D4", fontWeight: 700 }}>Dr. Chen:</span> "Only as needed. Switch to Tylenol if the sensitivity is mild. Continue soft foods for two more weeks and..."
            </div>
          </div>

          <div style={{ display: "flex", gap: 6 }}>
            <button style={{ flex: 1, background: "#DC2626", color: "#FFF", border: "none", borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>⏹️ Stop Recording</button>
            <button style={{ background: `${C.card}`, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 600, cursor: "pointer", color: C.muted }}>⏸️ Pause</button>
          </div>
        </Card>

        {/* Generated Note */}
        <Card>
          <CardTitle>📋 AI-Generated SOAP Note</CardTitle>
          {[
            { label: "S — Subjective", text: "Patient reports mild sensitivity at implant site #14 when chewing. Ibuprofen provides relief. Denies numbness, swelling, or drainage.", color: "#0891B2" },
            { label: "O — Objective", text: "Implant #14 stable, no mobility. Tissue healthy, pink, stippled. No suppuration. Probing: 3mm circumferential. CBCT confirms osseointegration progressing normally at 6 weeks. Occlusion checked — no premature contacts.", color: "#7C3AED" },
            { label: "A — Assessment", text: "Implant #14 healing within normal parameters. Sensitivity consistent with early loading adaptation. No signs of peri-implantitis.", color: "#EA580C" },
            { label: "P — Plan", text: "Continue soft diet 2 weeks. Return 8 weeks for final impression (D6058 abutment + D6065 implant crown). OTC analgesics PRN. Home care instructions reinforced.", color: C.success },
          ].map((s, i) => (
            <div key={i} style={{ marginBottom: 8, padding: "8px 10px", background: `${s.color}05`, borderLeft: `3px solid ${s.color}30`, borderRadius: "0 7px 7px 0" }}>
              <div style={{ fontSize: 9, fontWeight: 800, color: s.color, letterSpacing: 1, textTransform: "uppercase", marginBottom: 2 }}>{s.label}</div>
              <div style={{ fontSize: 11, color: "#94A3B8", lineHeight: 1.5 }}>{s.text}</div>
            </div>
          ))}
          <div style={{ background: "#0D0F18", borderRadius: 8, padding: "8px 10px", marginTop: 6 }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, marginBottom: 3 }}>AUTO-CODED CDT</div>
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
              {[{ code: "D0220", desc: "PA X-Ray" }, { code: "D0367", desc: "CBCT" }, { code: "D6010", desc: "Implant body" }, { code: "D0171", desc: "Re-evaluation" }].map(c => (
                <span key={c.code} style={{ background: `${C.accent}10`, borderRadius: 5, padding: "3px 8px", fontSize: 10, fontWeight: 700, color: C.accent }}>{c.code} <span style={{ color: C.muted, fontWeight: 400 }}>{c.desc}</span></span>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
            <button style={{ background: C.success, color: "#FFF", border: "none", borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>✓ Sign Note</button>
            <button style={{ background: `${C.accent}10`, color: C.accent, border: `1px solid ${C.accent}20`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>✏️ Edit</button>
            <button style={{ background: `${C.card}`, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 600, cursor: "pointer", color: C.muted }}>🔄 Regenerate</button>
          </div>
        </Card>
      </div>
    </>
  );
}

// ═══════════════════════════════════════
// 6. CLAIMS AI — Automated Claim Attachments
// ═══════════════════════════════════════
function ClaimsAIPanel() {
  return (
    <>
      <Alert color={C.success}>
        <strong>ClaimsAI</strong> automates claim attachment assembly — selects the most clinically relevant images, generates tailored narratives, and submits in one click. Up to 90% faster submissions, thousands recovered per month per location.
      </Alert>

      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="📋" label="Claims Processed (MTD)" value="142" sub="90% faster vs manual" color={C.accent} />
        <Kpi icon="💰" label="Revenue Recovered" value="$24,800" sub="From reduced denials" color={C.success} />
        <Kpi icon="✅" label="Clean Claim Rate" value="97.4%" sub="Up from 82% pre-AI" color="#7C3AED" />
        <Kpi icon="⏱️" label="Avg Assembly Time" value="12 sec" sub="Was 8-12 min manual" color="#0891B2" />
        <Kpi icon="📎" label="Auto-Attachments" value="284" sub="Images + narratives" color="#EA580C" />
        <Kpi icon="🔄" label="Denial Reduction" value="-68%" sub="Since ClaimsAI launch" color={C.teal} />
      </Grid>

      <Card style={{ marginTop: 14 }}>
        <CardTitle>📋 One-Click Claim Assembly Queue</CardTitle>
        {[
          { patient: "Margaret Sullivan", proc: "D2750 — Crown #14", images: 3, narrative: true, status: "ready", payer: "Delta Dental PPO", amount: "$1,180", confidence: "98%" },
          { patient: "Robert Kim", proc: "D6010 — Implant body #14", images: 5, narrative: true, status: "submitted", payer: "MetLife", amount: "$2,200", confidence: "96%" },
          { patient: "James Okafor", proc: "D4341 — SRP (2 quads)", images: 4, narrative: true, status: "ready", payer: "Cigna DPPO", amount: "$640", confidence: "94%" },
          { patient: "Diana Patel", proc: "D8090 — Comprehensive ortho", images: 6, narrative: true, status: "approved", payer: "Aetna", amount: "$3,300", confidence: "99%" },
          { patient: "Michael Torres", proc: "D6058 + D6065 — Abutment + Crown", images: 4, narrative: true, status: "pending_review", payer: "GEHA", amount: "$2,600", confidence: "91%" },
        ].map((c, i) => (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "1.3fr 1.5fr 60px 70px 1fr 80px 60px 80px", padding: "10px 0", borderBottom: `1px solid ${C.border}`, alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 700 }}>{c.patient}</span>
            <span style={{ fontSize: 10, fontFamily: "'JetBrains Mono'", color: C.accent }}>{c.proc}</span>
            <span style={{ fontSize: 10, color: C.muted }}>📎 {c.images} imgs</span>
            <span style={{ fontSize: 10, color: c.narrative ? C.success : C.muted }}>{c.narrative ? "✓ Narrative" : "—"}</span>
            <span style={{ fontSize: 10, color: C.muted }}>{c.payer}</span>
            <span style={{ fontSize: 12, fontWeight: 800, fontFamily: "'JetBrains Mono'" }}>{c.amount}</span>
            <span style={{ fontSize: 10, fontWeight: 700, color: "#7C3AED" }}>{c.confidence}</span>
            <Badge color={c.status === "approved" ? C.success : c.status === "submitted" ? C.accent : c.status === "ready" ? "#F59E0B" : C.muted}>{c.status.replace("_", " ")}</Badge>
          </div>
        ))}
      </Card>

      {/* Narrative Preview */}
      <Card style={{ marginTop: 14 }}>
        <CardTitle>📝 AI-Generated Clinical Narrative — Margaret Sullivan, D2750 #14</CardTitle>
        <div style={{ background: `${C.accent}05`, borderRadius: 10, padding: "14px 18px", border: `1px solid ${C.accent}10`, fontSize: 11, lineHeight: 1.7, color: "#94A3B8" }}>
          Patient presented with advanced interproximal caries on the mesial surface of tooth #14, confirmed by periapical radiograph dated 02/15/2026 (AI detection confidence: 96%). Clinical examination revealed loss of marginal ridge integrity with undermined enamel. The existing restoration was inadequate to restore tooth structure. CBCT imaging confirmed no periapical pathology. Due to the extent of structural compromise, a full-coverage crown (D2750) was treatment planned and accepted by the patient. Attached: periapical radiograph with AI annotations, intraoral photograph, and CBCT cross-section of #14.
        </div>
        <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
          <button style={{ background: C.success, color: "#FFF", border: "none", borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>🚀 Submit Claim</button>
          <button style={{ background: `${C.accent}10`, color: C.accent, border: `1px solid ${C.accent}20`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>✏️ Edit Narrative</button>
          <button style={{ background: `${C.card}`, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 16px", fontSize: 11, fontWeight: 600, cursor: "pointer", color: C.muted }}>📎 Review Attachments</button>
        </div>
      </Card>
    </>
  );
}

// ═══════════════════════════════════════
// 7. INSIGHTS AI — Enterprise Analytics
// ═══════════════════════════════════════
function InsightsAIPanel() {
  return (
    <>
      <Alert color="#7C3AED">
        <strong>InsightsAI</strong> surfaces up to $100K in additional treatment opportunities per practice per month and reduces in-person mentorship visits by 50%. Lead with insight, not oversight.
      </Alert>

      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="💰" label="Untreated Opportunities" value="$94,200" sub="This month" color="#EA580C" />
        <Kpi icon="📊" label="Diagnosis Rate" value="3.8" sub="Per exam (benchmark: 2.4)" color={C.accent} />
        <Kpi icon="🎯" label="Treatment Conversion" value="74%" sub="AI-detected → accepted" color={C.success} />
        <Kpi icon="👥" label="Provider Variance" value="18%" sub="Diagnosis consistency gap" color="#F59E0B" />
        <Kpi icon="🏢" label="Locations Tracked" value="4" sub="Real-time benchmarking" color="#7C3AED" />
        <Kpi icon="🧑‍🏫" label="Coaching Visits Saved" value="6" sub="This quarter (-50%)" color="#0891B2" />
      </Grid>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
        {/* Provider Benchmarking */}
        <Card>
          <CardTitle>👨‍⚕️ Provider AI Diagnostic Benchmarking</CardTitle>
          {[
            { name: "Dr. Chen", role: "Implantologist", dxRate: 4.2, acceptRate: 78, aiAgree: 94, missed: 2, trend: "↑", color: C.success },
            { name: "Dr. Park", role: "Orthodontist", dxRate: 3.8, acceptRate: 72, aiAgree: 91, missed: 4, trend: "→", color: C.accent },
            { name: "Dr. Okafor", role: "Oral Surgeon", dxRate: 3.1, acceptRate: 68, aiAgree: 87, missed: 7, trend: "↓", color: "#F59E0B" },
            { name: "Sarah M. RDH", role: "Hygienist", dxRate: 3.6, acceptRate: 70, aiAgree: 89, missed: 5, trend: "↑", color: C.success },
          ].map((p, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "1.2fr 60px 60px 60px 50px 30px", padding: "8px 0", borderBottom: `1px solid ${C.border}`, alignItems: "center" }}>
              <div><div style={{ fontSize: 12, fontWeight: 700 }}>{p.name}</div><div style={{ fontSize: 9, color: C.muted }}>{p.role}</div></div>
              <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 900, fontFamily: "'JetBrains Mono'" }}>{p.dxRate}</div><div style={{ fontSize: 8, color: C.muted }}>Dx/Exam</div></div>
              <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 900, fontFamily: "'JetBrains Mono'", color: C.success }}>{p.acceptRate}%</div><div style={{ fontSize: 8, color: C.muted }}>Accept</div></div>
              <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 900, fontFamily: "'JetBrains Mono'", color: "#7C3AED" }}>{p.aiAgree}%</div><div style={{ fontSize: 8, color: C.muted }}>AI Agree</div></div>
              <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 900, fontFamily: "'JetBrains Mono'", color: "#DC2626" }}>{p.missed}</div><div style={{ fontSize: 8, color: C.muted }}>Missed</div></div>
              <span style={{ fontSize: 16, color: p.color, textAlign: "center" }}>{p.trend}</span>
            </div>
          ))}
          <div style={{ fontSize: 10, color: C.muted, marginTop: 8, fontStyle: "italic" }}>"Missed" = findings AI detected that provider did not diagnose. Used for coaching, not punitive.</div>
        </Card>

        {/* Untreated Opportunities */}
        <Card>
          <CardTitle>💰 Untreated Treatment Opportunities</CardTitle>
          {[
            { category: "Undiagnosed caries (AI-detected)", count: 34, value: "$28,400", urgency: "high" },
            { category: "Aligner candidates (OrthoAI)", count: 18, value: "$22,600", urgency: "medium" },
            { category: "Implant candidates (ImplantAI)", count: 12, value: "$18,200", urgency: "medium" },
            { category: "Overdue perio treatment", count: 22, value: "$14,800", urgency: "high" },
            { category: "Pending treatment plans (accepted, unscheduled)", count: 16, value: "$10,200", urgency: "low" },
          ].map((o, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600 }}>{o.category}</div>
                <div style={{ fontSize: 10, color: C.muted }}>{o.count} patients</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 900, fontFamily: "'JetBrains Mono'" }}>{o.value}</span>
                <Badge color={o.urgency === "high" ? "#DC2626" : o.urgency === "medium" ? "#F59E0B" : C.muted}>{o.urgency}</Badge>
              </div>
            </div>
          ))}
          <div style={{ background: "#0D0F18", borderRadius: 8, padding: "10px 12px", marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 12, fontWeight: 800 }}>TOTAL UNTREATED VALUE</span>
            <span style={{ fontSize: 18, fontWeight: 900, color: "#EA580C", fontFamily: "'JetBrains Mono'" }}>$94,200</span>
          </div>
        </Card>
      </div>
    </>
  );
}

// ═══════════════════════════════════════
// 8. IMPACT PANEL — Revenue Attribution
// ═══════════════════════════════════════
function ImpactPanel() {
  return (
    <>
      <Grid cols="repeat(auto-fit, minmax(155px, 1fr))">
        <Kpi icon="💰" label="AI Revenue Impact (MTD)" value="$141,600" sub="Directly attributable" color={C.success} />
        <Kpi icon="📈" label="Acceptance Lift" value="+22%" sub="With AI presentation" color="#7C3AED" />
        <Kpi icon="🔬" label="Additional Diagnoses" value="148" sub="AI-only detections MTD" color="#DC2626" />
        <Kpi icon="⏱️" label="Time Saved" value="68 hrs" sub="Voice Notes + ClaimsAI" color="#0891B2" />
        <Kpi icon="🚫" label="Denials Prevented" value="$18,400" sub="ClaimsAI attribution" color="#EA580C" />
        <Kpi icon="📊" label="ROI Multiple" value="28.4x" sub="Monthly AI cost: $497" color={C.accent} />
      </Grid>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
        {/* Module Attribution */}
        <Card>
          <CardTitle>💰 Revenue Attribution by AI Module</CardTitle>
          {[
            { module: "ClinicalAI (Pathology Detection)", value: "$48,200", pct: 34, color: "#DC2626", icon: "🔬" },
            { module: "OrthoAI (Aligner Candidates)", value: "$28,600", pct: 20, color: "#7C3AED", icon: "🦷" },
            { module: "ImplantAI (Implant Candidates)", value: "$24,800", pct: 18, color: C.accent, icon: "🔩" },
            { module: "ClaimsAI (Revenue Recovery)", value: "$18,400", pct: 13, color: "#EA580C", icon: "📋" },
            { module: "Patient View (Acceptance Lift)", value: "$12,600", pct: 9, color: C.success, icon: "🖥️" },
            { module: "Voice Notes (Efficiency Gains)", value: "$9,000", pct: 6, color: "#0891B2", icon: "🎤" },
          ].map((m, i) => (
            <div key={i} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                <span style={{ fontSize: 11, fontWeight: 600 }}>{m.icon} {m.module}</span>
                <span style={{ fontSize: 12, fontWeight: 900, fontFamily: "'JetBrains Mono'", color: m.color }}>{m.value}</span>
              </div>
              <Pbar v={m.pct} color={m.color} h={6} />
            </div>
          ))}
          <div style={{ background: "#0D0F18", borderRadius: 8, padding: "10px 12px", marginTop: 8, display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontSize: 13, fontWeight: 900 }}>TOTAL AI VALUE (MTD)</span>
            <span style={{ fontSize: 18, fontWeight: 900, color: C.success, fontFamily: "'JetBrains Mono'" }}>$141,600</span>
          </div>
          <div style={{ fontSize: 10, color: C.muted, marginTop: 6 }}>Annualized: <strong style={{ color: C.success }}>$1,699,200</strong> • Platform cost: $497/mo • <strong style={{ color: "#7C3AED" }}>ROI: 28.4x</strong></div>
        </Card>

        {/* vs VideaHealth Comparison */}
        <Card>
          <CardTitle>⚡ DentAI vs. Standalone AI Tools</CardTitle>
          <div style={{ fontSize: 10, color: C.muted, marginBottom: 10 }}>Why unified beats fragmented — competitive feature matrix</div>
          {[
            { feature: "Pathology Detections", dentai: "34+", competitor: "34", winner: "tie" },
            { feature: "Pediatric AI (Age 3+)", dentai: "✓", competitor: "✓", winner: "tie" },
            { feature: "CBCT + Pano + PA Analysis", dentai: "✓ All integrated", competitor: "PA/BWX focus", winner: "dentai" },
            { feature: "Ambient Voice Scribe", dentai: "✓ Linked to imaging", competitor: "✓ Standalone", winner: "dentai" },
            { feature: "Auto CDT Coding", dentai: "✓ + CPT cross-code", competitor: "✓ CDT only", winner: "dentai" },
            { feature: "Claims AI", dentai: "✓ + Denial appeals", competitor: "✓ Attachments", winner: "dentai" },
            { feature: "OrthoAI Candidates", dentai: "✓ + Full tracker", competitor: "✓ Flag only", winner: "dentai" },
            { feature: "ImplantAI Candidates", dentai: "✓ + Full pipeline", competitor: "✓ Flag only", winner: "dentai" },
            { feature: "Insurance Verification", dentai: "✓ Built-in", competitor: "AutoVerify add-on", winner: "dentai" },
            { feature: "Medical Cross-Coding", dentai: "✓ CDT→CPT engine", competitor: "✗", winner: "dentai" },
            { feature: "AI Phone Agent", dentai: "✓ 24/7", competitor: "✗", winner: "dentai" },
            { feature: "Fee Schedule Optimizer", dentai: "✓", competitor: "✗", winner: "dentai" },
            { feature: "Unified BI Dashboard", dentai: "✓ 36 modules", competitor: "VideaInsights only", winner: "dentai" },
            { feature: "Cost", dentai: "$497/mo", competitor: "$800-1,200/mo", winner: "dentai" },
          ].map((f, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr 1fr 30px", padding: "5px 0", borderBottom: `1px solid ${C.border}`, alignItems: "center", fontSize: 10 }}>
              <span style={{ fontWeight: 600 }}>{f.feature}</span>
              <span style={{ color: f.winner === "dentai" || f.winner === "tie" ? C.success : C.muted, fontWeight: 700 }}>{f.dentai}</span>
              <span style={{ color: f.winner === "competitor" || f.winner === "tie" ? C.success : C.muted }}>{f.competitor}</span>
              <span>{f.winner === "dentai" ? "✅" : f.winner === "tie" ? "🟰" : "—"}</span>
            </div>
          ))}
        </Card>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════
// MAIN EXPORT — VideaAI Module with Sub-Tab Router
// ═══════════════════════════════════════════════════
export function VideaAIView() {
  const [subTab, setSubTab] = useState("clinical");

  return (
    <Section title="🔬 DentAI Imaging Intelligence" sub="34+ pathology detections · Ambient voice scribe · Claims automation · Enterprise analytics — matches & exceeds VideaHealth">
      <SubTab tabs={SUB_TABS} active={subTab} onChange={setSubTab} />

      {subTab === "clinical" && <ClinicalAIPanel />}
      {subTab === "patient" && <PatientViewPanel />}
      {subTab === "ortho" && <OrthoAIPanel />}
      {subTab === "implant" && <ImplantAIPanel />}
      {subTab === "voice" && <VoiceNotesPanel />}
      {subTab === "claims" && <ClaimsAIPanel />}
      {subTab === "insights" && <InsightsAIPanel />}
      {subTab === "impact" && <ImpactPanel />}
    </Section>
  );
}
