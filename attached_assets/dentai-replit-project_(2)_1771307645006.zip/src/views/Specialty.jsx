import React from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Row, Grid } from "../ui";

// ═══ 8. ORTHO TRACKER ═══
export function OrthoView() {
  return (
    <Section title="🦷 Orthodontic Tracker" sub="Invisalign tray tracking, bracket charting, compliance monitoring">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🦷" label="Active Cases" value="34" sub="28 Invisalign, 6 brackets" color={C.purple} />
        <Kpi icon="📅" label="Check-ins This Week" value="12" color={C.accent} />
        <Kpi icon="✅" label="On-Track Rate" value="91%" sub="3 patients behind" color={C.success} />
        <Kpi icon="💰" label="Ortho Revenue MTD" value="$48,200" color={C.teal} />
      </Grid>
      <Card>
        <CardTitle>Active Invisalign Cases</CardTitle>
        {[["Diana Patel","8/22","95%","on_track","2026-02-20"],["Emma Rodriguez","14/30","88%","on_track","2026-02-25"],["Tyler Nguyen","3/18","100%","on_track","2026-03-01"],["Sophia Adams","18/24","72%","behind","2026-02-14"]].map(([p,trays,comp,st,next],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr 70px 1fr 70px 70px 80px",padding:"8px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{p}</span>
            <span style={{fontWeight:800,color:C.purple,fontFamily:"'JetBrains Mono'"}}>{trays}</span>
            <Pbar v={parseInt(trays)/parseInt(trays.split("/")[1])*100} color={C.purple} h={4} />
            <span style={{fontWeight:600,color:parseInt(comp)>=90?C.success:C.warning}}>{comp}</span>
            <Badge color={st==="on_track"?C.success:C.warning}>{st==="on_track"?"On Track":"Behind"}</Badge>
            <span style={{color:C.muted}}>{next}</span>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 9. IMPLANT TRACKER ═══
export function ImplantView() {
  return (
    <Section title="🔩 Implant Case Tracker" sub="Stage-based workflow from consult through final restoration">
      <Grid cols={3} style={{marginBottom:14}}>
        <Kpi icon="🔩" label="Active Cases" value="18" sub="6 healing, 8 restoring, 4 new" color={C.accent} />
        <Kpi icon="💰" label="Implant Revenue MTD" value="$87,400" color={C.success} />
        <Kpi icon="✅" label="Success Rate" value="98.4%" sub="1 complication in 62" color={C.teal} />
      </Grid>
      <Card>
        <CardTitle>Implant Pipeline</CardTitle>
        <Grid cols={5} gap={8}>
          {[{s:"Consult",icon:"🎯",c:4,pts:["Robert Kim #14","Sarah Chen #30","Lisa Park #8,9","Tom Davis #19"],color:C.accent},{s:"Surgery",icon:"🔪",c:3,pts:["Michael Torres #17","John Wu #3","Amy Lee #14,15"],color:C.purple},{s:"Healing",icon:"⏳",c:6,pts:["Margaret Sullivan #14","David Park #5","Karen Brown #18","Pete Hall #30","Raj Patel #3","Nina Fox #10"],color:C.warning},{s:"Impression",icon:"📸",c:3,pts:["Jim Lee #14","Maria Garcia #19","Steve Chen #3"],color:C.teal},{s:"Restoration",icon:"👑",c:2,pts:["Emily Watson #12","Frank Morris #8"],color:C.success}].map(st => (
            <div key={st.s} style={{background:`${st.color}05`,border:`1px solid ${st.color}12`,borderRadius:10,padding:"10px 12px"}}>
              <Row style={{marginBottom:6}}><span style={{fontSize:11,fontWeight:800,color:st.color}}>{st.icon} {st.s}</span><span style={{fontSize:16,fontWeight:900,color:st.color}}>{st.c}</span></Row>
              {st.pts.map((p,i) => <div key={i} style={{fontSize:10,color:"#7A8298",padding:"2px 0",borderBottom:i<st.pts.length-1?`1px solid ${C.border}`:"none"}}>{p}</div>)}
            </div>
          ))}
        </Grid>
      </Card>
    </Section>
  );
}

// ═══ 10. LAB CASES ═══
export function LabView() {
  return (
    <Section title="🔬 Lab Case Manager" sub="Track every case from scan to delivery">
      <Grid cols={3} style={{marginBottom:14}}>
        <Kpi icon="📦" label="Active Cases" value="23" sub="8 overdue" color={C.accent} />
        <Kpi icon="💰" label="Lab Costs MTD" value="$14,200" sub="7.1% of production" color={C.warning} />
        <Kpi icon="⏱️" label="Avg Turnaround" value="8.2 days" sub="Target: 7 days" color={C.orange} />
      </Grid>
      <Card>
        {[["Margaret Sullivan","Crown PFM #3","Burbank Lab","A2","Jan 28","Feb 8","Overdue",C.danger],["Emily Watson","Crown e.max #12","Glidewell","B1","Feb 5","Feb 14","In Progress",C.warning],["Robert Kim","Implant Abutment #14","Straumann","—","Feb 10","Feb 24","Submitted",C.accent],["Diana Patel","Invisalign Trays 9-12","Align Tech","—","Feb 8","Feb 18","Fabricating",C.accent],["Frank Morris","Implant Crown #8","Burbank Lab","A1","Feb 1","Feb 11","Ready",C.success]].map(([p,type,lab,shade,sent,due,st,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.2fr 1.2fr 1fr 40px 60px 60px 80px",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{p}</span><span style={{color:"#8892A8"}}>{type}</span><span style={{color:C.muted}}>{lab}</span><span>{shade}</span><span style={{color:C.muted}}>{sent}</span><span style={{color:C.muted}}>{due}</span><Badge color={color}>{st}</Badge>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 11. REFERRAL MANAGEMENT ═══
export function ReferralView() {
  return (
    <Section title="🔄 Referral Management" sub="Inbound/outbound referrals, specialist network, revenue attribution">
      <Grid cols={3} style={{marginBottom:14}}>
        <Kpi icon="📤" label="Referrals Out MTD" value="14" sub="8 perio, 4 OS, 2 endo" color={C.accent} />
        <Kpi icon="📥" label="Referrals In MTD" value="22" sub="$186K revenue" color={C.success} />
        <Kpi icon="🔗" label="Network Specialists" value="12" color={C.purple} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>Top Referring Doctors (Inbound)</CardTitle>
          {[["Dr. Anderson (GP)",8,"$68,400"],["Dr. Williams (GP)",5,"$42,100"],["Dr. Garcia (Pedo)",4,"$34,800"],["Dr. Lee (Endo)",3,"$24,200"],["Dr. Brown (Ortho)",2,"$16,500"]].map(([n,ref,rev],i) => (
            <Row key={i} bb={i<4}><span style={{fontSize:11,fontWeight:600}}>{n}</span><div style={{display:"flex",gap:8}}><span style={{fontSize:10,color:C.muted}}>{ref} pts</span><span style={{fontSize:10,fontWeight:700,color:C.success}}>{rev}</span></div></Row>
          ))}
        </Card>
        <Card>
          <CardTitle>Outbound Referral Status</CardTitle>
          {[["James Okafor","Dr. Park (Perio)","SRP + surgery","seen",C.success],["Michael Torres","Dr. Smith (Cardio)","Warfarin pre-surgery","pending",C.warning],["Sarah Chen","Dr. Okafor (OS)","Wisdom extraction","scheduled",C.accent]].map(([p,to,reason,st,color],i) => (
            <div key={i} style={{padding:"7px 0",borderBottom:i<2?`1px solid ${C.border}`:"none"}}>
              <Row><span style={{fontSize:11,fontWeight:700}}>{p}</span><Badge color={color}>{st}</Badge></Row>
              <div style={{fontSize:10,color:C.muted}}>→ {to} · {reason}</div>
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}
