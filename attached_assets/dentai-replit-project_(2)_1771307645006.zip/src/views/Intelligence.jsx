import React from "react";
import { C } from "../theme";
import { Badge, Pbar, Kpi, Section, Card, CardTitle, Row, Grid, Alert } from "../ui";

// ═══ 27. FINANCIAL CENTER ═══
export function FinancialView() {
  return (
    <Section title="💰 Financial Command Center" sub="P&L, cash flow, budgets, overhead breakdown, tax prep">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="💵" label="YTD Revenue" value="$498,240" sub="↑ 18% vs LY" color={C.success} />
        <Kpi icon="💰" label="Net Income MTD" value="$86,400" sub="43.2% margin" color={C.accent} />
        <Kpi icon="📊" label="Overhead %" value="57.3%" sub="Target: <59%" color={C.teal} />
        <Kpi icon="💳" label="A/P Outstanding" value="$18,200" sub="3 vendors due" color={C.warning} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>P&L Summary — February 2026</CardTitle>
          {[["Production (Gross)","$206,400","",true,C.text],["Adjustments","($7,200)","3.5%",false,C.muted],["Net Production","$199,200","",true,C.accent],["Collections","$198,240","99.5%",true,C.success],["— Staff Costs","($52,800)","26.6%",false,C.muted],["— Facility","($14,400)","7.3%",false,C.muted],["— Supplies & Lab","($25,600)","12.9%",false,C.muted],["— Marketing","($8,200)","4.1%",false,C.muted],["— Admin & Other","($12,800)","6.5%",false,C.muted],["Total Overhead","($113,800)","57.3%",true,C.warning],["NET INCOME","$84,440","42.6%",true,C.success]].map(([cat,val,pct,bold,color],i) => (
            <Row key={i} style={{borderBottom:bold?`1px solid ${C.border}`:"none"}}><span style={{fontSize:11,fontWeight:bold?800:400,color}}>{cat}</span><div style={{display:"flex",gap:10}}>{pct&&<span style={{fontSize:10,color:C.muted}}>{pct}</span>}<span style={{fontSize:11,fontWeight:bold?800:600,fontFamily:"'JetBrains Mono'",color}}>{val}</span></div></Row>
          ))}
        </Card>
        <Card>
          <CardTitle>Overhead Breakdown</CardTitle>
          {[["Staff (salaries + benefits)",26.6,28,C.success],["Supplies & Lab",12.9,14,C.success],["Facility (rent + utilities)",7.3,8,C.success],["Admin & Technology",6.5,4,C.danger],["Marketing",4.1,5,C.success]].map(([cat,pct,target,color],i) => (
            <div key={i} style={{marginBottom:8}}>
              <Row><span style={{fontSize:11}}>{cat}</span><span style={{fontSize:11,fontWeight:700,color}}>{pct}% <span style={{color:C.muted,fontWeight:400}}>/ {target}%</span></span></Row>
              <Pbar v={pct/target*100} color={color} h={4} />
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 28. PATIENT FINANCING ═══
export function FinancingView() {
  return (
    <Section title="💳 Patient Financing Engine" sub="In-house payment plans, auto-charge, no third-party fees">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="💳" label="Active Plans" value="47" sub="$284K outstanding" color={C.accent} />
        <Kpi icon="✅" label="On-Time Rate" value="94%" sub="3 past due" color={C.success} />
        <Kpi icon="💰" label="Collected MTD" value="$42,800" color={C.teal} />
        <Kpi icon="📊" label="Avg Plan" value="$3,240" sub="12-month avg" color={C.purple} />
      </Grid>
      <Card>
        {[["Margaret Sullivan","Implant #14","$2,600","$216.67/mo","$1,950","3/12","Current",C.success],["Diana Patel","Invisalign","$3,300","$275/mo","$2,475","3/12","Current",C.success],["Michael Torres","Graft + implant","$475","$158.33/mo","$316.67","1/3","Current",C.success],["Tom Davis","Full arch","$12,400","$516.67/mo","$9,300","6/24","Late 5d",C.warning]].map(([p,tx,total,mo,rem,pmts,st,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.2fr 1fr 70px 80px 70px 50px 70px",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{p}</span><span style={{color:C.muted}}>{tx}</span><span style={{fontFamily:"'JetBrains Mono'"}}>{total}</span><span style={{fontFamily:"'JetBrains Mono'"}}>{mo}</span><span style={{fontFamily:"'JetBrains Mono'"}}>{rem}</span><span>{pmts}</span><Badge color={color}>{st}</Badge>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 29. MARKETING SUITE ═══
export function MarketingView() {
  return (
    <Section title="📣 Marketing Suite" sub="Content calendar, ad management, review monitoring, ROI attribution">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="👤" label="New Patients Feb" value="38" sub="Target: 45" color={C.accent} />
        <Kpi icon="💰" label="Marketing Spend" value="$8,200" sub="4.1% of revenue" color={C.warning} />
        <Kpi icon="📊" label="Cost/Patient" value="$216" sub="Target: <$300" color={C.success} />
        <Kpi icon="⭐" label="Google Rating" value="4.9" sub="234 reviews" color={C.teal} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>📊 Channel Performance</CardTitle>
          {[["Google Ads","$3,200",14,"$229","8.2x",C.accent],["Meta/Instagram","$2,100",8,"$263","5.4x",C.purple],["Google Organic","$800",6,"$133","12.1x",C.success],["Patient Referrals","$1,500",6,"$250","9.8x",C.teal],["Direct Mail","$600",2,"$300","4.2x",C.muted],["Walk-ins","$0",2,"$0","∞",C.orange]].map(([ch,spend,pts,cpa,roi,color],i) => (
            <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr 65px 40px 55px 45px",padding:"5px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
              <span style={{fontWeight:600}}>{ch}</span><span style={{fontFamily:"'JetBrains Mono'"}}>{spend}</span><span style={{fontWeight:700}}>{pts}</span><span style={{fontFamily:"'JetBrains Mono'"}}>{cpa}</span><span style={{fontWeight:800,color}}>{roi}</span>
            </div>
          ))}
        </Card>
        <Card>
          <CardTitle>📅 Content Calendar</CardTitle>
          {[["Mon","Before/after implant photo","IG+FB","posted",C.success],["Tue","3 Signs You Need RCT video","TikTok","scheduled",C.accent],["Wed","Patient testimonial — Diana P.","IG+FB","scheduled",C.accent],["Thu","Blog: Implants vs Bridges","Website","draft",C.warning],["Fri","Team BTS reel","IG+TikTok","idea",C.muted]].map(([day,content,platform,st,color],i) => (
            <Row key={i} bb={i<4}><div style={{display:"flex",alignItems:"center",gap:6}}><span style={{fontSize:10,fontWeight:800,color:C.accent,width:25}}>{day}</span><div><div style={{fontSize:10,fontWeight:600}}>{content}</div><div style={{fontSize:9,color:C.muted}}>{platform}</div></div></div><Badge color={color}>{st}</Badge></Row>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 30. PATIENT NPS ═══
export function NpsView() {
  return (
    <Section title="⭐ Patient Satisfaction & NPS" sub="Post-visit surveys, sentiment analysis, review routing">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="⭐" label="NPS Score" value="78" sub="Excellent (target: 70+)" color={C.success} />
        <Kpi icon="😊" label="Promoters" value="82%" sub="Score 9-10" color={C.success} />
        <Kpi icon="😐" label="Passives" value="14%" sub="Score 7-8" color={C.warning} />
        <Kpi icon="😞" label="Detractors" value="4%" sub="3 patients" color={C.danger} />
      </Grid>
      <Alert color={C.success} icon="🤖" title="AI Review Routing">Patients scoring 9-10 auto-receive Google review link. Scores ≤6 route to office manager. AI generates draft response for each review within 30 minutes.</Alert>
    </Section>
  );
}

// ═══ 31. FEE OPTIMIZER ═══
export function FeesView() {
  return (
    <Section title="💲 AI Fee Schedule Optimizer" sub="UCR analysis, PPO fee negotiation, procedure profitability">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="💲" label="Revenue Opportunity" value="$42,800" sub="From fee optimization" color={C.emerald} />
        <Kpi icon="📊" label="Below UCR" value="34" sub="Of 180 active codes" color={C.warning} />
        <Kpi icon="📈" label="Fee vs UCR" value="88%" sub="Target: 95%" color={C.accent} />
        <Kpi icon="🔄" label="PPO Contracts" value="8" sub="3 need renegotiation" color={C.purple} />
      </Grid>
      <Card>
        <CardTitle>Fee Schedule — Top Procedures</CardTitle>
        <div style={{display:"grid",gridTemplateColumns:"60px 2fr 80px 80px 80px 80px 70px",padding:"6px 0",borderBottom:`2px solid ${C.border}`,fontSize:9,fontWeight:700,color:C.muted,letterSpacing:0.5,textTransform:"uppercase"}}>
          {["CDT","Procedure","Your Fee","UCR 80th","Delta","Cigna","Action"].map(h => <div key={h}>{h}</div>)}
        </div>
        {[["D0120","Periodic Eval","$52","$65","$48","$45","↑20%",C.warning],["D1110","Adult Prophy","$110","$142","$95","$88","↑23%",C.warning],["D2391","Composite 1-surf","$195","$228","$165","$158","↑14%",C.warning],["D2740","Crown Porcelain","$1,280","$1,420","$980","$920","✓ Good",C.success],["D4341","SRP 4+ teeth","$245","$290","$205","$195","↑16%",C.warning],["D6010","Implant Body","$2,200","$2,480","$1,650","$1,580","✓ Good",C.success]].map(([code,desc,fee,ucr,delta,cigna,action,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"60px 2fr 80px 80px 80px 80px 70px",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontFamily:"'JetBrains Mono'",fontWeight:700,color:C.purple}}>{code}</span>
            <span style={{color:"#8892A8"}}>{desc}</span>
            <span style={{fontWeight:700,fontFamily:"'JetBrains Mono'"}}>{fee}</span>
            <span style={{color:C.success,fontFamily:"'JetBrains Mono'"}}>{ucr}</span>
            <span style={{color:C.warning,fontFamily:"'JetBrains Mono'"}}>{delta}</span>
            <span style={{color:C.danger,fontFamily:"'JetBrains Mono'"}}>{cigna}</span>
            <Badge color={color}>{action}</Badge>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 32. PROVIDER INTEL ═══
export function ProviderView() {
  return (
    <Section title="👨‍⚕️ Provider Performance Intelligence" sub="Production, coding patterns, speed metrics, compensation modeling">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="👨‍⚕️" label="Providers" value="3" sub="+ 2 hygienists" color={C.accent} />
        <Kpi icon="💰" label="Production MTD" value="$198,200" color={C.emerald} />
        <Kpi icon="📊" label="Avg Prod/Day" value="$8,260" color={C.success} />
        <Kpi icon="🎯" label="Avg Acceptance" value="74%" sub="↑ 6% with AI" color={C.cyan} />
      </Grid>
      <Card>
        <CardTitle>Provider Scorecard</CardTitle>
        <div style={{display:"grid",gridTemplateColumns:"1.4fr repeat(7,1fr)",padding:"6px 0",borderBottom:`2px solid ${C.border}`,fontSize:9,fontWeight:700,color:C.muted,letterSpacing:0.5,textTransform:"uppercase"}}>
          {["Provider","Production","Prod/Day","Patients","Case Accept","Avg Tx","Collections","Score"].map(h => <div key={h}>{h}</div>)}
        </div>
        {[["Dr. Chen|Implantologist","$98,400","$8,200","142","78%","$2,840","$96,200","A+",C.success],["Dr. Park|Orthodontist","$62,800","$7,850","98","72%","$1,680","$61,400","A",C.success],["Dr. Okafor|Oral Surgeon","$37,000","$9,250","48","68%","$3,420","$36,200","A-",C.success],["Sarah M.|Hygienist","$18,400","$920","164","—","$112","$18,100","A",C.success],["Jamie L.|Hyg/Perio","$16,800","$840","148","—","$114","$16,500","B+",C.warning]].map(([name,prod,perDay,pts,accept,avgTx,coll,score,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.4fr repeat(7,1fr)",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <div><div style={{fontWeight:800}}>{name.split("|")[0]}</div><div style={{fontSize:9,color:C.muted}}>{name.split("|")[1]}</div></div>
            <span style={{fontWeight:700,fontFamily:"'JetBrains Mono'"}}>{prod}</span>
            <span style={{fontFamily:"'JetBrains Mono'"}}>{perDay}</span>
            <span>{pts}</span>
            <span style={{fontWeight:700,color:parseInt(accept)>=75?C.success:parseInt(accept)>=65?C.warning:C.muted}}>{accept}</span>
            <span style={{fontFamily:"'JetBrains Mono'"}}>{avgTx}</span>
            <span style={{color:C.success,fontFamily:"'JetBrains Mono'"}}>{coll}</span>
            <span style={{fontWeight:900,color,fontSize:14}}>{score}</span>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 33. PAYER INTELLIGENCE ═══
export function PayerView() {
  return (
    <Section title="🏦 Payer Intelligence Dashboard" sub="AI learns from every claim — payer profiles, playbooks, revenue opportunities">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🏦" label="Payer Profiles" value="340+" color={C.accent} />
        <Kpi icon="📊" label="Claims Analyzed" value="12,400+" color={C.purple} />
        <Kpi icon="⏱️" label="Avg Days to Pay" value="14.2" color={C.success} />
        <Kpi icon="💰" label="Opportunities" value="$18,400" sub="Revenue detected" color={C.emerald} />
      </Grid>
      <Card>
        <CardTitle>🏦 Top Payer Scorecard</CardTitle>
        {[["Delta Dental Premier","92%","12d","4%","94%","Medium","A+",C.success],["Cigna PPO","86%","18d","8%","88%","High","A",C.success],["MetLife PPO","81%","22d","12%","82%","High","B+",C.warning],["Aetna DMO","78%","16d","9%","75%","Low","B",C.warning],["UHC PPO","74%","28d","15%","71%","High","C+",C.danger],["BCBS FEP","88%","14d","6%","90%","Medium","A",C.success]].map(([payer,approve,days,denial,reimb,xcode,score,color],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr 65px 50px 55px 60px 65px 45px",padding:"7px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:11}}>
            <span style={{fontWeight:700}}>{payer}</span>
            <span style={{color:C.success}}>{approve}</span>
            <span style={{fontFamily:"'JetBrains Mono'"}}>{days}</span>
            <span style={{color:parseFloat(denial)>10?C.danger:C.warning}}>{denial}</span>
            <span style={{fontFamily:"'JetBrains Mono'"}}>{reimb}</span>
            <span style={{color:xcode==="High"?C.purple:C.muted}}>{xcode}</span>
            <span style={{fontWeight:900,color,fontSize:13}}>{score}</span>
          </div>
        ))}
      </Card>
    </Section>
  );
}

// ═══ 34. MULTI-LOCATION ═══
export function MultiLocView() {
  return (
    <Section title="🏢 Multi-Location Command Center" sub="Side-by-side performance, centralized management, location benchmarking">
      <Card>
        <div style={{display:"grid",gridTemplateColumns:"1.5fr repeat(6,1fr)",padding:"8px 0",borderBottom:`2px solid ${C.border}`,fontSize:9,fontWeight:700,color:C.muted,letterSpacing:0.6,textTransform:"uppercase"}}>
          {["Location","Production","Collections%","New Pts","Accept%","Overhead","Net Margin"].map(h => <div key={h}>{h}</div>)}
        </div>
        {[["Auburn Main","$198,200","96.2%","38","72%","57.3%","42.7%","↑"],["Roseville","$142,800","94.8%","28","68%","61.2%","33.6%","↑"],["Folsom","$168,400","97.1%","34","74%","55.8%","41.3%","↑"],["Rocklin (New)","$84,200","92.4%","22","64%","68.4%","24.0%","↑"]].map(([loc,prod,coll,np,accept,overhead,margin,trend],i) => (
          <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr repeat(6,1fr)",padding:"10px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:12}}>
            <span style={{fontWeight:800}}>{loc} <span style={{color:C.success}}>{trend}</span></span>
            <span style={{fontWeight:700,fontFamily:"'JetBrains Mono'"}}>{prod}</span>
            <span style={{color:parseFloat(coll)>=96?C.success:C.warning,fontWeight:700}}>{coll}</span>
            <span style={{fontWeight:700}}>{np}</span>
            <span style={{color:parseInt(accept)>=70?C.success:C.warning,fontWeight:700}}>{accept}</span>
            <span style={{color:parseFloat(overhead)<60?C.success:C.danger,fontWeight:700}}>{overhead}</span>
            <span style={{fontWeight:800,color:parseFloat(margin)>=40?C.success:parseFloat(margin)>=30?C.warning:C.danger}}>{margin}</span>
          </div>
        ))}
        <div style={{display:"grid",gridTemplateColumns:"1.5fr repeat(6,1fr)",padding:"10px 0",background:C.card2,fontWeight:800,fontSize:12}}>
          <span>TOTAL (4 Locations)</span>
          <span style={{fontFamily:"'JetBrains Mono'"}}>$593,600</span>
          <span>95.4%</span><span>122</span><span>70%</span><span>58.7%</span><span style={{color:C.success}}>37.9%</span>
        </div>
      </Card>
    </Section>
  );
}

// ═══ 35. COMPLIANCE AUDIT ═══
export function ComplianceView() {
  return (
    <Section title="🛡️ AI Compliance & Coding Audit" sub="Real-time audit, documentation completeness, HIPAA compliance">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="🛡️" label="Compliance Score" value="96.4%" sub="Excellent" color={C.success} />
        <Kpi icon="📋" label="Charts Audited" value="342" sub="100% auto-audited" color={C.accent} />
        <Kpi icon="⚠️" label="Issues Found" value="12" sub="8 resolved, 4 pending" color={C.warning} />
        <Kpi icon="💰" label="Risk Avoided" value="$28,400" color={C.emerald} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>🔍 Coding Audit — This Week</CardTitle>
          {[["D2950 without crown code","Dr. Chen","2 cases","high","Unbundling risk — D2740 attached",C.danger],["D0220 PA + D0330 Pano same day","Dr. Park","1 case","med","Modifier documentation added",C.warning],["D4341 SRP without perio chart","Sarah RDH","3 cases","high","Perio charts attached retroactively",C.danger],["Narrative missing D2740 >$1,200","Dr. Chen","2 cases","med","AI auto-generated narratives",C.warning]].map(([issue,prov,cases,risk,action,color],i) => (
            <Alert key={i} color={color} icon="🔍" title={<>{issue} <Badge color={color}>{risk}</Badge></>}>{prov} · {cases} — 🤖 {action}</Alert>
          ))}
        </Card>
        <Card>
          <CardTitle>📋 Documentation Completeness</CardTitle>
          {[["SOAP notes signed",98,C.success],["Perio charts with SRP",88,C.warning],["Consent forms on file",100,C.success],["X-rays attached to claims",95,C.success],["Medical history <12mo",82,C.warning],["Narratives on major procs",91,C.success],["Pre-auth documentation",96,C.success]].map(([doc,pct,color],i) => (
            <div key={i} style={{marginBottom:6}}>
              <Row><span style={{fontSize:10}}>{doc}</span><span style={{fontSize:10,fontWeight:700,color}}>{pct}%</span></Row>
              <Pbar v={pct} color={color} h={3} />
            </div>
          ))}
        </Card>
      </Grid>
    </Section>
  );
}

// ═══ 36. UNIFIED BUSINESS INTELLIGENCE ═══
export function BiView() {
  return (
    <Section title="📊 Unified Business Intelligence" sub="Cross-module analytics, AI value attribution, competitive benchmarking, strategic recommendations">
      <Grid cols={4} style={{marginBottom:14}}>
        <Kpi icon="💰" label="Annualized Revenue" value="$2.38M" sub="Run rate" color={C.emerald} />
        <Kpi icon="📈" label="Growth Rate" value="+18%" sub="YoY" color={C.success} />
        <Kpi icon="🏆" label="Percentile" value="92nd" sub="vs national" color={C.accent} />
        <Kpi icon="🤖" label="AI Impact" value="$384K" sub="Annual value from AI" color={C.purple} />
      </Grid>
      <Grid cols={2}>
        <Card>
          <CardTitle>🤖 AI Value Attribution — Monthly</CardTitle>
          {[["🔬 AI Diagnostics","$8,400",C.accent],["📞 AI Phone Agent","$18,400",C.cyan],["📋 Claims Engine","$6,200",C.teal],["🔀 Cross-Coding","$28,400",C.purple],["⚔️ Denial Appeals","$34,200",C.warning],["🎯 Case Acceptance","$22,800",C.success],["📅 Smart Scheduling","$12,400",C.orange],["🎤 Voice Pipeline","$4,800",C.rose],["💲 Fee Optimization","$3,600",C.lime],["🛡️ Compliance","$2,400",C.sky]].map(([mod,impact,color],i) => (
            <Row key={i} bb>
              <span style={{fontSize:11}}>{mod}</span>
              <span style={{fontSize:12,fontWeight:900,color,fontFamily:"'JetBrains Mono'"}}>{impact}</span>
            </Row>
          ))}
          <Row style={{paddingTop:8,borderTop:`2px solid ${C.border}`,marginTop:6}}>
            <span style={{fontSize:14,fontWeight:900}}>Total Monthly AI Value</span>
            <span style={{fontSize:18,fontWeight:900,color:C.emerald,fontFamily:"'JetBrains Mono'"}}>$141,600</span>
          </Row>
          <div style={{textAlign:"center",fontSize:11,color:C.muted,marginTop:4}}>= <strong style={{color:C.emerald,fontSize:14}}>$1.7M/year</strong> from AI — at <strong style={{color:C.accent}}>$497/mo</strong></div>
        </Card>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <Card>
            <CardTitle>📊 Practice vs Benchmarks</CardTitle>
            {[["Production/Operatory","$24,800","$18,200","94th",C.success],["Collection Rate","99.5%","96.2%","98th",C.success],["Overhead %","57.3%","62.8%","88th",C.success],["New Patients/Mo","38","28","86th",C.success],["Case Acceptance","74%","58%","92nd",C.success],["Days in A/R","18.4","32","95th",C.success],["Hygiene Reappt","88%","82%","78th",C.warning],["Patient Retention","91%","85%","84th",C.success]].map(([metric,yours,bench,pctile,color],i) => (
              <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr 65px 65px 55px",padding:"4px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center",fontSize:10}}>
                <span>{metric}</span>
                <span style={{fontWeight:800,fontFamily:"'JetBrains Mono'"}}>{yours}</span>
                <span style={{color:C.muted,fontFamily:"'JetBrains Mono'"}}>{bench}</span>
                <Badge color={color}>{pctile}</Badge>
              </div>
            ))}
          </Card>
          <div style={{background:`linear-gradient(135deg, ${C.accent}08, ${C.purple}08)`,border:`1px solid ${C.accent}15`,borderRadius:12,padding:"14px 16px"}}>
            <div style={{fontSize:11,fontWeight:800,color:C.accent,marginBottom:6}}>🧠 AI Strategic Recommendations</div>
            {["Hygiene reappt at 88% — implement AI phone recall for non-responders","Cross-coding at 34/mo — potential 60+ with TMJ, sleep, trauma detection","Rocklin 68.4% overhead — share hygienist with Auburn until breakeven","SEO ROI at 12.1x — increase AI blog content to 2x/week"].map((r,i) => (
              <div key={i} style={{fontSize:9,color:"#7A8298",padding:"3px 0 3px 10px",borderLeft:`2px solid ${C.accent}25`,marginBottom:4,lineHeight:1.4}}>💡 {r}</div>
            ))}
          </div>
        </div>
      </Grid>
    </Section>
  );
}
