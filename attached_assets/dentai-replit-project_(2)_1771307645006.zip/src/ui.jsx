import React from "react";
import { C } from "./theme";

// ═══ BADGE ═══
export const Badge = ({ children, color = C.accent, solid, pulse }) => (
  <span
    style={{
      background: solid ? color : `${color}15`,
      color: solid ? "#FFF" : color,
      padding: "2px 9px",
      borderRadius: 6,
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: 0.3,
      textTransform: "uppercase",
      whiteSpace: "nowrap",
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
    }}
  >
    {pulse && (
      <span
        style={{
          width: 5,
          height: 5,
          borderRadius: "50%",
          background: solid ? "#FFF" : color,
          animation: "blink 2s infinite",
        }}
      />
    )}
    {children}
  </span>
);

// ═══ PROGRESS BAR ═══
export const Pbar = ({ v, color = C.accent, h = 5 }) => (
  <div
    style={{
      height: h,
      background: "#1A1D2E",
      borderRadius: h,
      overflow: "hidden",
      flex: 1,
    }}
  >
    <div
      style={{
        height: "100%",
        width: `${Math.min(v, 100)}%`,
        background: `linear-gradient(90deg, ${color}88, ${color})`,
        borderRadius: h,
        transition: "width 0.7s cubic-bezier(.4,0,.2,1)",
      }}
    />
  </div>
);

// ═══ KPI CARD ═══
export const Kpi = ({ label, value, sub, color = C.accent, icon }) => (
  <div
    style={{
      background: C.card,
      border: `1px solid ${C.border}`,
      borderRadius: 14,
      padding: "15px 17px",
      position: "relative",
      overflow: "hidden",
    }}
  >
    <div
      style={{
        position: "absolute",
        top: -18,
        right: -18,
        width: 60,
        height: 60,
        background: `${color}08`,
        borderRadius: "50%",
        filter: "blur(14px)",
      }}
    />
    <div
      style={{
        fontSize: 9,
        color: C.muted,
        letterSpacing: 1.4,
        textTransform: "uppercase",
        fontWeight: 600,
        marginBottom: 3,
      }}
    >
      {icon} {label}
    </div>
    <div
      style={{
        fontSize: 22,
        fontWeight: 900,
        fontFamily: "'JetBrains Mono', monospace",
      }}
    >
      {value}
    </div>
    {sub && (
      <div style={{ fontSize: 10, color, fontWeight: 600, marginTop: 2 }}>
        {sub}
      </div>
    )}
  </div>
);

// ═══ SECTION HEADER ═══
export const Section = ({ title, sub, children }) => (
  <div style={{ marginBottom: 22, animation: "fadeIn 0.3s ease-out" }}>
    <div style={{ marginBottom: 13 }}>
      <div style={{ fontSize: 21, fontWeight: 900, letterSpacing: -0.4 }}>
        {title}
      </div>
      {sub && (
        <div style={{ fontSize: 12, color: C.muted, marginTop: 2 }}>{sub}</div>
      )}
    </div>
    {children}
  </div>
);

// ═══ CARD ═══
export const Card = ({ children, style: s }) => (
  <div
    style={{
      background: C.card,
      border: `1px solid ${C.border}`,
      borderRadius: 14,
      padding: "16px 18px",
      ...s,
    }}
  >
    {children}
  </div>
);

// ═══ CARD TITLE ═══
export const CardTitle = ({ children }) => (
  <div style={{ fontSize: 13, fontWeight: 800, marginBottom: 10 }}>
    {children}
  </div>
);

// ═══ ROW ═══
export const Row = ({ children, bb, style: s }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "6px 0",
      borderBottom: bb ? `1px solid ${C.border}` : "none",
      ...s,
    }}
  >
    {children}
  </div>
);

// ═══ GRID ═══
export const Grid = ({ cols = 2, gap = 12, children, style: s }) => (
  <div
    style={{
      display: "grid",
      gridTemplateColumns: `repeat(auto-fit, minmax(${Math.floor(
        600 / cols
      )}px, 1fr))`,
      gap,
      ...s,
    }}
  >
    {children}
  </div>
);

// ═══ ALERT ═══
export const Alert = ({ color, icon, title, children }) => (
  <div
    style={{
      background: `${color}06`,
      borderLeft: `3px solid ${color}`,
      borderRadius: "0 10px 10px 0",
      padding: "10px 14px",
      marginBottom: 7,
    }}
  >
    <div style={{ fontSize: 11, fontWeight: 800, color, marginBottom: 2 }}>
      {icon} {title}
    </div>
    <div style={{ fontSize: 10, color: "#8892A8", lineHeight: 1.5 }}>
      {children}
    </div>
  </div>
);

// ═══ METRIC INLINE ═══
export const Metric = ({ label, value, color }) => (
  <div>
    <span style={{ fontSize: 10, color: C.muted }}>{label}: </span>
    <span
      style={{
        fontSize: 11,
        fontWeight: 700,
        color: color || C.text,
        fontFamily: "'JetBrains Mono'",
      }}
    >
      {value}
    </span>
  </div>
);
