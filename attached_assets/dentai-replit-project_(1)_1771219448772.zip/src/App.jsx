import { useState } from "react";
import { C, MODULES, GROUP_ICONS } from "./theme";
import { IntakeView, PerioView, SoapView, ImagingView, ConsentView, ErxView, AiClinicalView } from "./views/Clinical";
import { OrthoView, ImplantView, LabView, ReferralView } from "./views/Specialty";
import { InventoryView, HrView, SterilizationView, ScheduleView } from "./views/Operations";
import { RcmView, VerifyView, ClaimsView, CrossCodeView, NecessityView, DenialsView } from "./views/Revenue";
import { PhoneView, VoiceView, TxPlanView, AcceptanceView, TelehealthView } from "./views/AIEngines";
import { FinancialView, FinancingView, MarketingView, NpsView, FeesView, ProviderView, PayerView, MultiLocView, ComplianceView, BiView } from "./views/Intelligence";

// ═══ MODULE → VIEW MAPPING ═══
const VIEW_MAP = {
  intake: IntakeView, perio: PerioView, soap: SoapView, imaging: ImagingView,
  consent: ConsentView, erx: ErxView, aiclinical: AiClinicalView,
  ortho: OrthoView, implant: ImplantView, lab: LabView, referral: ReferralView,
  inventory: InventoryView, hr: HrView, sterilization: SterilizationView, schedule: ScheduleView,
  rcm: RcmView, verify: VerifyView, claims: ClaimsView, crosscode: CrossCodeView,
  necessity: NecessityView, denials: DenialsView,
  phone: PhoneView, voice: VoiceView, txplan: TxPlanView, acceptance: AcceptanceView,
  telehealth: TelehealthView,
  financial: FinancialView, financing: FinancingView, marketing: MarketingView, nps: NpsView,
  fees: FeesView, provider: ProviderView, payer: PayerView, multiloc: MultiLocView,
  compliance: ComplianceView, bi: BiView,
};

export default function App() {
  const [tab, setTab] = useState("rcm");
  const groups = [...new Set(MODULES.map(m => m.group))];
  const ActiveView = VIEW_MAP[tab];

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: C.bg, fontFamily: "'Outfit', system-ui, sans-serif", color: C.text }}>

      {/* ═══ SIDEBAR ═══ */}
      <div style={{
        width: 215, background: C.sidebar, padding: "12px 8px",
        display: "flex", flexDirection: "column", flexShrink: 0,
        borderRight: `1px solid ${C.border}`, overflowY: "auto",
      }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 9, padding: "6px 10px", marginBottom: 12 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 9,
            background: "linear-gradient(135deg, #6C5CE7, #00C48C, #FFB020)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 15, boxShadow: "0 0 20px rgba(108,92,231,0.4)",
          }}>🦷</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 900, color: "#F0F2F8", letterSpacing: -0.3 }}>DentAI</div>
            <div style={{ fontSize: 7, color: C.sideText, letterSpacing: 3, textTransform: "uppercase" }}>Unified Platform</div>
          </div>
        </div>

        {/* Status pill */}
        <div style={{
          background: `${C.accent}08`, border: `1px solid ${C.accent}15`,
          borderRadius: 9, padding: "8px 11px", margin: "0 4px 10px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: C.success, boxShadow: `0 0 6px ${C.success}` }} />
            <span style={{ fontSize: 10, color: C.success, fontWeight: 700 }}>36 Modules · All Active</span>
          </div>
          <div style={{ fontSize: 9, color: C.sideText, marginTop: 3 }}>Replaces $4,200+/mo in software</div>
        </div>

        {/* Navigation */}
        {groups.map(g => (
          <div key={g}>
            <div style={{
              fontSize: 8, color: "#2A2E3E", letterSpacing: 2.2,
              textTransform: "uppercase", fontWeight: 800, padding: "10px 11px 3px",
            }}>{GROUP_ICONS[g]} {g}</div>
            {MODULES.filter(m => m.group === g).map(m => (
              <button
                key={m.id}
                onClick={() => setTab(m.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 7,
                  padding: "6px 10px", borderRadius: 7, border: "none",
                  background: tab === m.id ? `${C.sideActive}12` : "transparent",
                  cursor: "pointer", width: "100%", transition: "0.12s",
                  borderLeft: tab === m.id ? `2px solid ${C.sideActive}` : "2px solid transparent",
                }}
              >
                <span style={{ fontSize: 12 }}>{m.icon}</span>
                <span style={{
                  fontSize: 10.5,
                  fontWeight: tab === m.id ? 700 : 500,
                  color: tab === m.id ? C.sideActive : C.sideText,
                }}>{m.label}</span>
              </button>
            ))}
          </div>
        ))}
      </div>

      {/* ═══ MAIN CONTENT ═══ */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px", minWidth: 0 }}>
        {ActiveView && <ActiveView />}
      </div>
    </div>
  );
}
