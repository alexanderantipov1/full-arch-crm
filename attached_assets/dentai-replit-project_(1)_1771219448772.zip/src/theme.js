// ═══════════════════════════════════════════════════════════════
// DENTAI DESIGN SYSTEM — Dark Theme Tokens
// ═══════════════════════════════════════════════════════════════

export const C = {
  bg: "#08090E",
  card: "#0F1118",
  card2: "#141720",
  border: "#1C1F2E",
  text: "#E8ECF4",
  muted: "#5C6478",
  accent: "#6C5CE7",
  success: "#00C48C",
  warning: "#FFB020",
  danger: "#FF4757",
  purple: "#A855F7",
  pink: "#F472B6",
  cyan: "#22D3EE",
  teal: "#2DD4BF",
  orange: "#FB923C",
  indigo: "#818CF8",
  emerald: "#34D399",
  lime: "#A3E635",
  rose: "#FB7185",
  sky: "#38BDF8",
  gold: "#F5C542",
  sidebar: "#060710",
  sideText: "#4A5068",
  sideActive: "#6C5CE7",
  glow: "rgba(108,92,231,0.12)",
};

export const GROUP_ICONS = {
  Clinical: "💉",
  Specialty: "🦷",
  Operations: "⚙️",
  "Revenue AI": "💰",
  "AI Engines": "🤖",
  Intelligence: "📊",
};

export const MODULES = [
  // Clinical
  { id: "intake", label: "Patient Intake", icon: "📋", group: "Clinical" },
  { id: "perio", label: "Perio Charting", icon: "📊", group: "Clinical" },
  { id: "soap", label: "Clinical Notes", icon: "📝", group: "Clinical" },
  { id: "imaging", label: "AI Diagnostics", icon: "🔬", group: "Clinical" },
  { id: "consent", label: "Consent Forms", icon: "✍️", group: "Clinical" },
  { id: "erx", label: "E-Prescribing", icon: "💊", group: "Clinical" },
  { id: "aiclinical", label: "Decision Support", icon: "🧠", group: "Clinical" },
  // Specialty
  { id: "ortho", label: "Ortho Tracker", icon: "🦷", group: "Specialty" },
  { id: "implant", label: "Implant Tracker", icon: "🔩", group: "Specialty" },
  { id: "lab", label: "Lab Cases", icon: "🔬", group: "Specialty" },
  { id: "referral", label: "Referrals", icon: "🔄", group: "Specialty" },
  // Operations
  { id: "inventory", label: "Inventory", icon: "📦", group: "Operations" },
  { id: "hr", label: "HR & Payroll", icon: "👥", group: "Operations" },
  { id: "sterilization", label: "Sterilization", icon: "🧪", group: "Operations" },
  { id: "schedule", label: "Smart Schedule", icon: "📅", group: "Operations" },
  // Revenue Cycle AI
  { id: "rcm", label: "Revenue Command", icon: "🎛️", group: "Revenue AI" },
  { id: "verify", label: "Insurance Verify", icon: "🔍", group: "Revenue AI" },
  { id: "claims", label: "Claims Engine", icon: "📋", group: "Revenue AI" },
  { id: "crosscode", label: "Cross-Coding", icon: "🔀", group: "Revenue AI" },
  { id: "necessity", label: "Necessity Letters", icon: "📄", group: "Revenue AI" },
  { id: "denials", label: "Denial Appeals", icon: "⚔️", group: "Revenue AI" },
  // AI Engines
  { id: "phone", label: "AI Phone Agent", icon: "📞", group: "AI Engines" },
  { id: "voice", label: "Voice-to-Code", icon: "🎤", group: "AI Engines" },
  { id: "txplan", label: "AI Tx Planning", icon: "🧠", group: "AI Engines" },
  { id: "acceptance", label: "Case Acceptance", icon: "🎯", group: "AI Engines" },
  { id: "telehealth", label: "Teledentistry", icon: "📹", group: "AI Engines" },
  // Business Intelligence
  { id: "financial", label: "Financial Center", icon: "💰", group: "Intelligence" },
  { id: "financing", label: "Patient Finance", icon: "💳", group: "Intelligence" },
  { id: "marketing", label: "Marketing Suite", icon: "📣", group: "Intelligence" },
  { id: "nps", label: "Patient NPS", icon: "⭐", group: "Intelligence" },
  { id: "fees", label: "Fee Optimizer", icon: "💲", group: "Intelligence" },
  { id: "provider", label: "Provider Intel", icon: "👨‍⚕️", group: "Intelligence" },
  { id: "payer", label: "Payer Intel", icon: "🏦", group: "Intelligence" },
  { id: "multiloc", label: "Multi-Location", icon: "🏢", group: "Intelligence" },
  { id: "compliance", label: "Compliance Audit", icon: "🛡️", group: "Intelligence" },
  { id: "bi", label: "Business Intel", icon: "📊", group: "Intelligence" },
];
