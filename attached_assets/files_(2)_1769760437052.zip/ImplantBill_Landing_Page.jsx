import React, { useState } from 'react';
import { Brain, Zap, FileText, Shield, Clock, DollarSign, CheckCircle, ArrowRight, Play, Star, ChevronDown, Menu, X } from 'lucide-react';

export default function ImplantBillLandingPage() {
  const [email, setEmail] = useState('');
  const [practiceName, setPracticeName] = useState('');
  const [casesPerMonth, setCasesPerMonth] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    // In production, this would send to your backend/Mailchimp/etc.
    console.log({ email, practiceName, casesPerMonth });
    setSubmitted(true);
  };

  const features = [
    { icon: Brain, title: "AI Medical Necessity Letters", desc: "Generate insurance-ready documentation in 30 seconds, not 30 minutes", color: "from-violet-500 to-purple-600" },
    { icon: Zap, title: "Smart Cross-Coding", desc: "99.2% accurate CDT → CPT/ICD-10 translation with medical necessity linking", color: "from-amber-500 to-orange-600" },
    { icon: FileText, title: "One-Click Prior Auth", desc: "Submit to 500+ payers instantly with auto-assembled documentation", color: "from-blue-500 to-cyan-600" },
    { icon: Shield, title: "AI Appeals Engine", desc: "78% overturn rate on denials with AI-generated appeal letters", color: "from-emerald-500 to-green-600" },
  ];

  const stats = [
    { value: "96%", label: "Clean Claim Rate", sublabel: "vs 45% industry avg" },
    { value: "78%", label: "Appeal Success", sublabel: "vs 25% industry avg" },
    { value: "32", label: "Days to Payment", sublabel: "vs 90-180 industry avg" },
    { value: "90%", label: "Time Savings", sublabel: "on billing tasks" },
  ];

  const testimonials = [
    { quote: "We were leaving $2M on the table annually. ImplantBill AI changed everything.", name: "Dr. Michael Chen", role: "Oral Surgeon, 3 Locations", rating: 5 },
    { quote: "My staff used to spend 40 hours per case on billing. Now it's under 4 hours.", name: "Dr. Sarah Williams", role: "Prosthodontist", rating: 5 },
    { quote: "The AI appeals have an incredible success rate. We've recovered $500K in denied claims.", name: "Dr. James Rodriguez", role: "Implant Center Director", rating: 5 },
  ];

  const faqs = [
    { q: "What procedures does ImplantBill AI support?", a: "We specialize in full arch dental implants (All-on-4, All-on-6, full mouth rehabilitation), including bone grafting, sinus lifts, and zygomatic implants. Our AI is trained specifically on these high-value procedures billed to medical insurance." },
    { q: "How does the AI generate medical necessity letters?", a: "Our AI is trained on thousands of successful claims and letters that resulted in approvals. You input patient clinical data, and the AI generates a compelling, payer-specific medical necessity letter in seconds. You review, edit if needed, and submit." },
    { q: "Is this HIPAA compliant?", a: "Yes. We use encrypted databases, secure cloud infrastructure with signed BAAs, role-based access control, and comprehensive audit logging. We take PHI security seriously." },
    { q: "What's the pricing?", a: "Plans start at $997/month for up to 15 cases. Professional ($2,497/mo) covers up to 40 cases. Enterprise ($4,997/mo) is unlimited with dedicated support. All plans include full AI features." },
    { q: "How long does implementation take?", a: "Most practices are up and running in 1-2 weeks. We handle data migration, integration with your practice management system, and staff training." },
  ];

  const pricingPlans = [
    { name: "Starter", price: "$997", period: "/month", cases: "Up to 15 cases/mo", features: ["AI Letter Generation", "Cross-Coding Engine", "Prior Auth Submission", "Basic Analytics", "Email Support"], popular: false },
    { name: "Professional", price: "$2,497", period: "/month", cases: "Up to 40 cases/mo", features: ["Everything in Starter", "AI Appeals Engine", "Clearinghouse Integration", "Advanced Analytics", "Priority Support", "3 Locations"], popular: true },
    { name: "Enterprise", price: "$4,997", period: "/month", cases: "Unlimited cases", features: ["Everything in Professional", "Unlimited Locations", "Custom Integrations", "Dedicated Success Manager", "API Access", "White Label Options"], popular: false },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Navigation */}
      <nav className="relative z-50 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">ImplantBill AI</span>
            </div>
            
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-slate-300 hover:text-white transition-colors">Features</a>
              <a href="#pricing" className="text-slate-300 hover:text-white transition-colors">Pricing</a>
              <a href="#faq" className="text-slate-300 hover:text-white transition-colors">FAQ</a>
              <button className="px-5 py-2.5 bg-gradient-to-r from-blue-500 to-violet-600 rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Join Waitlist
              </button>
            </div>

            <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 pt-20 pb-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full mb-8 backdrop-blur-sm border border-white/10">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-sm text-slate-300">Now accepting beta practices</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
              <span className="bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">
                Stop Leaving Millions
              </span>
              <br />
              <span className="bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">
                On The Table
              </span>
            </h1>
            
            <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              AI-powered medical billing for full arch dental implants. 
              Generate medical necessity letters in seconds. Get paid in weeks, not months.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <a href="#waitlist" className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-blue-500 to-violet-600 rounded-xl font-semibold text-lg hover:opacity-90 transition-all hover:scale-105 flex items-center justify-center gap-2">
                Join the Waitlist <ArrowRight className="w-5 h-5" />
              </a>
              <button className="w-full sm:w-auto px-8 py-4 bg-white/10 rounded-xl font-semibold text-lg hover:bg-white/20 transition-all flex items-center justify-center gap-2 backdrop-blur-sm border border-white/10">
                <Play className="w-5 h-5" /> Watch Demo
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, i) => (
                <div key={i} className="p-6 bg-white/5 rounded-2xl backdrop-blur-sm border border-white/10">
                  <div className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent mb-1">
                    {stat.value}
                  </div>
                  <div className="text-white font-medium">{stat.label}</div>
                  <div className="text-sm text-slate-500">{stat.sublabel}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="relative z-10 py-24 px-6 bg-gradient-to-b from-transparent to-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">The $2M Problem Nobody Talks About</h2>
            <p className="text-xl text-slate-400">
              Full arch implants are $25K-50K cases. But 80% of practices don't bill medical insurance because...
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { emoji: "😤", title: "It's Too Complicated", desc: "Cross-coding, medical necessity letters, payer-specific requirements... your staff wasn't trained for this." },
              { emoji: "⏰", title: "It Takes Forever", desc: "40+ hours per case for documentation, prior auth, follow-up, and appeals. That's a full work week." },
              { emoji: "❌", title: "Denials Kill You", desc: "85% denial rate on first submission. Most practices give up after the first rejection." },
            ].map((item, i) => (
              <div key={i} className="p-8 bg-white/5 rounded-2xl border border-white/10 hover:border-red-500/50 transition-colors">
                <div className="text-5xl mb-4">{item.emoji}</div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-slate-400">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative z-10 py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">AI Superpowers for Your Billing Team</h2>
            <p className="text-xl text-slate-400">
              Purpose-built for full arch implants. Not generic billing software pretending to know dental.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {features.map((feature, i) => (
              <div key={i} className="group p-8 bg-white/5 rounded-2xl border border-white/10 hover:border-white/30 transition-all hover:-translate-y-1">
                <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                <p className="text-slate-400 text-lg">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative z-10 py-24 px-6 bg-gradient-to-b from-slate-900/50 to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">From Consultation to Collection in 4 Steps</h2>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Enter Clinical Data", desc: "Input patient diagnosis, exam findings, and treatment plan" },
              { step: "02", title: "AI Generates Docs", desc: "Medical necessity letter, coding, and prior auth package created in seconds" },
              { step: "03", title: "One-Click Submit", desc: "Send to insurance with all required documentation attached" },
              { step: "04", title: "Track & Collect", desc: "Monitor status, auto-appeal denials, and get paid faster" },
            ].map((item, i) => (
              <div key={i} className="relative">
                <div className="p-6 bg-white/5 rounded-2xl border border-white/10 h-full">
                  <div className="text-5xl font-bold text-white/10 mb-4">{item.step}</div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-slate-400">{item.desc}</p>
                </div>
                {i < 3 && (
                  <div className="hidden md:block absolute top-1/2 -right-3 transform -translate-y-1/2 text-white/20">
                    <ArrowRight className="w-6 h-6" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative z-10 py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Simple, Predictable Pricing</h2>
            <p className="text-xl text-slate-400">
              Flat monthly fee. No percentage of collections. No hidden costs.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {pricingPlans.map((plan, i) => (
              <div key={i} className={`relative p-8 rounded-2xl border ${plan.popular ? 'bg-gradient-to-b from-blue-500/20 to-violet-500/20 border-blue-500/50' : 'bg-white/5 border-white/10'}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-blue-500 to-violet-600 rounded-full text-sm font-semibold">
                    Most Popular
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-1">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-slate-400">{plan.period}</span>
                </div>
                <p className="text-slate-400 mb-6">{plan.cases}</p>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                      <span className="text-slate-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className={`w-full py-3 rounded-xl font-semibold transition-all ${plan.popular ? 'bg-gradient-to-r from-blue-500 to-violet-600 hover:opacity-90' : 'bg-white/10 hover:bg-white/20'}`}>
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="relative z-10 py-24 px-6 bg-gradient-to-b from-transparent to-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Trusted by Leading Implant Practices</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <div key={i} className="p-8 bg-white/5 rounded-2xl border border-white/10">
                <div className="flex gap-1 mb-4">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} className="w-5 h-5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-lg mb-6 text-slate-300">"{t.quote}"</p>
                <div>
                  <div className="font-bold">{t.name}</div>
                  <div className="text-slate-500 text-sm">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="relative z-10 py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="border border-white/10 rounded-xl overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full p-6 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
                >
                  <span className="font-semibold text-lg">{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-6 text-slate-400">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Waitlist CTA */}
      <section id="waitlist" className="relative z-10 py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="p-12 bg-gradient-to-br from-blue-500/20 to-violet-500/20 rounded-3xl border border-white/10 text-center">
            <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Billing?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Join the waitlist for early access. Limited spots for founding practices.
            </p>

            {submitted ? (
              <div className="p-6 bg-emerald-500/20 rounded-xl border border-emerald-500/50">
                <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">You're on the list!</h3>
                <p className="text-slate-300">We'll be in touch soon with exclusive early access.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-5 py-4 bg-white/10 rounded-xl border border-white/20 focus:border-blue-500 focus:outline-none placeholder-slate-500"
                />
                <input
                  type="text"
                  placeholder="Practice name"
                  value={practiceName}
                  onChange={(e) => setPracticeName(e.target.value)}
                  required
                  className="w-full px-5 py-4 bg-white/10 rounded-xl border border-white/20 focus:border-blue-500 focus:outline-none placeholder-slate-500"
                />
                <select
                  value={casesPerMonth}
                  onChange={(e) => setCasesPerMonth(e.target.value)}
                  required
                  className="w-full px-5 py-4 bg-white/10 rounded-xl border border-white/20 focus:border-blue-500 focus:outline-none text-slate-300"
                >
                  <option value="" className="bg-slate-900">Full arch cases per month</option>
                  <option value="1-5" className="bg-slate-900">1-5 cases/month</option>
                  <option value="6-15" className="bg-slate-900">6-15 cases/month</option>
                  <option value="16-30" className="bg-slate-900">16-30 cases/month</option>
                  <option value="30+" className="bg-slate-900">30+ cases/month</option>
                </select>
                <button
                  type="submit"
                  className="w-full py-4 bg-gradient-to-r from-blue-500 to-violet-600 rounded-xl font-semibold text-lg hover:opacity-90 transition-all"
                >
                  Join the Waitlist
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold">ImplantBill AI</span>
          </div>
          <div className="text-slate-500 text-sm">
            © 2026 ImplantBill AI. Built by oral surgeons, for oral surgeons.
          </div>
          <div className="flex gap-6 text-slate-400">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
