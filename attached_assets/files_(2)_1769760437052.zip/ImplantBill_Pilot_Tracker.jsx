import React, { useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Plus, FileText, Clock, DollarSign, CheckCircle, XCircle, AlertCircle, TrendingUp, Building2, Calendar, Download, Filter, ChevronDown, Edit2, Trash2, Eye } from 'lucide-react';

// Sample data - in production this would come from your database
const initialCases = [
  { id: 'IB-001', patientInitials: 'RM', dos: '2026-01-15', procedure: 'All-on-4 Maxilla', clinic: 'Clinic 1', totalFee: 47500, insurance: 'UnitedHealthcare', letterTime: 1.5, letterQuality: 9, codesAccepted: true, priorAuthStatus: 'approved', claimStatus: 'paid', amountPaid: 38000, daysToPayment: 28 },
  { id: 'IB-002', patientInitials: 'SW', dos: '2026-01-18', procedure: 'Full Arch Mandible', clinic: 'Clinic 2', totalFee: 52000, insurance: 'Aetna', letterTime: 2.0, letterQuality: 8, codesAccepted: true, priorAuthStatus: 'approved', claimStatus: 'pending', amountPaid: 0, daysToPayment: null },
  { id: 'IB-003', patientInitials: 'JT', dos: '2026-01-20', procedure: 'All-on-6 Bilateral', clinic: 'Clinic 1', totalFee: 89500, insurance: 'Cigna', letterTime: 1.8, letterQuality: 9, codesAccepted: true, priorAuthStatus: 'pending', claimStatus: 'in_auth', amountPaid: 0, daysToPayment: null },
  { id: 'IB-004', patientInitials: 'MG', dos: '2026-01-22', procedure: 'Full Arch + Graft', clinic: 'Clinic 3', totalFee: 61000, insurance: 'Blue Cross', letterTime: 2.5, letterQuality: 7, codesAccepted: false, priorAuthStatus: 'denied', claimStatus: 'appealed', amountPaid: 0, daysToPayment: null },
  { id: 'IB-005', patientInitials: 'DC', dos: '2026-01-25', procedure: 'Zygomatic Implants', clinic: 'Clinic 2', totalFee: 78000, insurance: 'Medicare', letterTime: 1.2, letterQuality: 10, codesAccepted: true, priorAuthStatus: 'approved', claimStatus: 'paid', amountPaid: 62400, daysToPayment: 35 },
];

const weeklyMetrics = [
  { week: 'Week 1', cases: 5, letters: 5, cleanClaims: 4, avgLetterTime: 1.8 },
  { week: 'Week 2', cases: 8, letters: 8, cleanClaims: 7, avgLetterTime: 1.5 },
  { week: 'Week 3', cases: 12, letters: 12, cleanClaims: 11, avgLetterTime: 1.3 },
  { week: 'Week 4', cases: 15, letters: 15, cleanClaims: 14, avgLetterTime: 1.1 },
];

export default function PilotTrackingDashboard() {
  const [cases, setCases] = useState(initialCases);
  const [showAddCase, setShowAddCase] = useState(false);
  const [filterClinic, setFilterClinic] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [activeTab, setActiveTab] = useState('dashboard');

  // Calculate metrics
  const totalCases = cases.length;
  const paidCases = cases.filter(c => c.claimStatus === 'paid');
  const totalBilled = cases.reduce((sum, c) => sum + c.totalFee, 0);
  const totalCollected = cases.reduce((sum, c) => sum + c.amountPaid, 0);
  const avgLetterTime = cases.reduce((sum, c) => sum + c.letterTime, 0) / totalCases;
  const avgLetterQuality = cases.reduce((sum, c) => sum + c.letterQuality, 0) / totalCases;
  const codesAcceptedRate = (cases.filter(c => c.codesAccepted).length / totalCases) * 100;
  const paidDays = paidCases.filter(c => c.daysToPayment).map(c => c.daysToPayment);
  const avgDaysToPayment = paidDays.length > 0 ? paidDays.reduce((a, b) => a + b, 0) / paidDays.length : 0;

  const statusColors = {
    approved: { bg: 'bg-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500' },
    pending: { bg: 'bg-amber-100', text: 'text-amber-700', dot: 'bg-amber-500' },
    denied: { bg: 'bg-red-100', text: 'text-red-700', dot: 'bg-red-500' },
    paid: { bg: 'bg-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500' },
    in_auth: { bg: 'bg-blue-100', text: 'text-blue-700', dot: 'bg-blue-500' },
    appealed: { bg: 'bg-purple-100', text: 'text-purple-700', dot: 'bg-purple-500' },
  };

  const clinicData = [
    { name: 'Clinic 1', cases: cases.filter(c => c.clinic === 'Clinic 1').length, collected: cases.filter(c => c.clinic === 'Clinic 1').reduce((s, c) => s + c.amountPaid, 0) },
    { name: 'Clinic 2', cases: cases.filter(c => c.clinic === 'Clinic 2').length, collected: cases.filter(c => c.clinic === 'Clinic 2').reduce((s, c) => s + c.amountPaid, 0) },
    { name: 'Clinic 3', cases: cases.filter(c => c.clinic === 'Clinic 3').length, collected: cases.filter(c => c.clinic === 'Clinic 3').reduce((s, c) => s + c.amountPaid, 0) },
  ];

  const claimStatusData = [
    { name: 'Paid', value: cases.filter(c => c.claimStatus === 'paid').length, color: '#10B981' },
    { name: 'Pending', value: cases.filter(c => c.claimStatus === 'pending').length, color: '#F59E0B' },
    { name: 'In Auth', value: cases.filter(c => c.claimStatus === 'in_auth').length, color: '#3B82F6' },
    { name: 'Appealed', value: cases.filter(c => c.claimStatus === 'appealed').length, color: '#8B5CF6' },
  ];

  const filteredCases = cases.filter(c => {
    if (filterClinic !== 'all' && c.clinic !== filterClinic) return false;
    if (filterStatus !== 'all' && c.claimStatus !== filterStatus) return false;
    return true;
  });

  const MetricCard = ({ icon: Icon, label, value, subValue, color, trend }) => (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-xl ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        {trend && (
          <span className={`text-sm font-medium flex items-center gap-1 ${trend > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            <TrendingUp className={`w-4 h-4 ${trend < 0 ? 'rotate-180' : ''}`} />
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <p className="text-slate-500 text-sm font-medium">{label}</p>
      <p className="text-2xl font-bold text-slate-800 mt-1">{value}</p>
      {subValue && <p className="text-sm text-slate-400 mt-1">{subValue}</p>}
    </div>
  );

  const StatusBadge = ({ status }) => {
    const style = statusColors[status] || statusColors.pending;
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${style.bg} ${style.text}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${style.dot}`}></span>
        {status.replace('_', ' ').charAt(0).toUpperCase() + status.replace('_', ' ').slice(1)}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800">ImplantBill AI Pilot Tracker</h1>
              <p className="text-sm text-slate-500">Internal testing across 3 clinics</p>
            </div>
            <div className="flex items-center gap-4">
              <button className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg flex items-center gap-2 transition-colors">
                <Download className="w-4 h-4" /> Export
              </button>
              <button 
                onClick={() => setShowAddCase(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" /> Add Case
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-8">
            {['dashboard', 'cases', 'weekly'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 border-b-2 font-medium transition-colors ${
                  activeTab === tab 
                    ? 'border-blue-600 text-blue-600' 
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)} {tab === 'dashboard' ? 'Overview' : tab === 'cases' ? 'Log' : 'Metrics'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <>
            {/* Metric Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <MetricCard icon={FileText} label="Total Cases" value={totalCases} subValue="In pilot program" color="bg-blue-500" />
              <MetricCard icon={Clock} label="Avg Letter Time" value={`${avgLetterTime.toFixed(1)} min`} subValue="Target: < 2 min" color="bg-violet-500" trend={-15} />
              <MetricCard icon={CheckCircle} label="Codes Accepted Rate" value={`${codesAcceptedRate.toFixed(0)}%`} subValue="Target: > 90%" color="bg-emerald-500" trend={8} />
              <MetricCard icon={DollarSign} label="Total Collected" value={`$${totalCollected.toLocaleString()}`} subValue={`of $${totalBilled.toLocaleString()} billed`} color="bg-amber-500" />
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
              {/* Clinic Comparison */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <h3 className="text-lg font-bold text-slate-800 mb-6">Cases by Clinic</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={clinicData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis dataKey="name" stroke="#64748B" fontSize={12} />
                    <YAxis stroke="#64748B" fontSize={12} />
                    <Tooltip />
                    <Bar dataKey="cases" fill="#3B82F6" radius={[4, 4, 0, 0]} name="Cases" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Claim Status Distribution */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <h3 className="text-lg font-bold text-slate-800 mb-6">Claim Status Distribution</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={claimStatusData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={4} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                      {claimStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Success Criteria */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Pilot Success Criteria</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Letter Quality Score', current: avgLetterQuality.toFixed(1), target: '≥ 8/10', met: avgLetterQuality >= 8 },
                  { label: 'Letter Generation Time', current: `${avgLetterTime.toFixed(1)} min`, target: '< 2 min', met: avgLetterTime < 2 },
                  { label: 'Codes Accepted Rate', current: `${codesAcceptedRate.toFixed(0)}%`, target: '≥ 90%', met: codesAcceptedRate >= 90 },
                  { label: 'Avg Days to Payment', current: avgDaysToPayment > 0 ? `${avgDaysToPayment.toFixed(0)} days` : 'N/A', target: '< 45 days', met: avgDaysToPayment > 0 && avgDaysToPayment < 45 },
                ].map((criteria, i) => (
                  <div key={i} className={`p-4 rounded-xl border-2 ${criteria.met ? 'border-emerald-200 bg-emerald-50' : 'border-amber-200 bg-amber-50'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-slate-600">{criteria.label}</span>
                      {criteria.met ? (
                        <CheckCircle className="w-5 h-5 text-emerald-500" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-amber-500" />
                      )}
                    </div>
                    <div className="text-2xl font-bold text-slate-800">{criteria.current}</div>
                    <div className="text-sm text-slate-500">Target: {criteria.target}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Cases Tab */}
        {activeTab === 'cases' && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100">
            {/* Filters */}
            <div className="p-6 border-b border-slate-100 flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600">Filter:</span>
              </div>
              <select
                value={filterClinic}
                onChange={(e) => setFilterClinic(e.target.value)}
                className="px-3 py-2 bg-slate-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Clinics</option>
                <option value="Clinic 1">Clinic 1</option>
                <option value="Clinic 2">Clinic 2</option>
                <option value="Clinic 3">Clinic 3</option>
              </select>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 bg-slate-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Statuses</option>
                <option value="paid">Paid</option>
                <option value="pending">Pending</option>
                <option value="in_auth">In Auth</option>
                <option value="appealed">Appealed</option>
              </select>
              <span className="text-sm text-slate-400 ml-auto">{filteredCases.length} cases</span>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-slate-500 border-b border-slate-100">
                    <th className="px-6 py-4 font-medium">Case ID</th>
                    <th className="px-6 py-4 font-medium">Patient</th>
                    <th className="px-6 py-4 font-medium">DOS</th>
                    <th className="px-6 py-4 font-medium">Procedure</th>
                    <th className="px-6 py-4 font-medium">Clinic</th>
                    <th className="px-6 py-4 font-medium">Letter Time</th>
                    <th className="px-6 py-4 font-medium">Quality</th>
                    <th className="px-6 py-4 font-medium">Prior Auth</th>
                    <th className="px-6 py-4 font-medium">Claim Status</th>
                    <th className="px-6 py-4 font-medium">Amount</th>
                    <th className="px-6 py-4 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCases.map((c) => (
                    <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-mono text-sm font-semibold text-blue-600">{c.id}</td>
                      <td className="px-6 py-4 font-medium text-slate-800">{c.patientInitials}</td>
                      <td className="px-6 py-4 text-slate-600 text-sm">{c.dos}</td>
                      <td className="px-6 py-4 text-slate-600 text-sm">{c.procedure}</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 bg-slate-100 rounded text-xs font-medium">{c.clinic}</span>
                      </td>
                      <td className="px-6 py-4 text-sm">{c.letterTime} min</td>
                      <td className="px-6 py-4">
                        <span className={`font-semibold ${c.letterQuality >= 8 ? 'text-emerald-600' : 'text-amber-600'}`}>
                          {c.letterQuality}/10
                        </span>
                      </td>
                      <td className="px-6 py-4"><StatusBadge status={c.priorAuthStatus} /></td>
                      <td className="px-6 py-4"><StatusBadge status={c.claimStatus} /></td>
                      <td className="px-6 py-4">
                        <div className="text-sm">
                          <div className="font-semibold">${c.amountPaid.toLocaleString()}</div>
                          <div className="text-slate-400">of ${c.totalFee.toLocaleString()}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                            <Eye className="w-4 h-4 text-slate-400" />
                          </button>
                          <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                            <Edit2 className="w-4 h-4 text-slate-400" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Weekly Metrics Tab */}
        {activeTab === 'weekly' && (
          <div className="space-y-8">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Weekly Pilot Progress</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={weeklyMetrics}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="week" stroke="#64748B" fontSize={12} />
                  <YAxis stroke="#64748B" fontSize={12} />
                  <Tooltip />
                  <Line type="monotone" dataKey="cases" stroke="#3B82F6" strokeWidth={2} dot={{ r: 4 }} name="Cases Processed" />
                  <Line type="monotone" dataKey="cleanClaims" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} name="Clean Claims" />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Letter Generation Time Trend</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={weeklyMetrics}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="week" stroke="#64748B" fontSize={12} />
                  <YAxis stroke="#64748B" fontSize={12} unit=" min" />
                  <Tooltip />
                  <Bar dataKey="avgLetterTime" fill="#8B5CF6" radius={[4, 4, 0, 0]} name="Avg Letter Time (min)" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Weekly Summary Table */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Weekly Summary</h3>
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-slate-500 border-b border-slate-100">
                    <th className="pb-4 font-medium">Week</th>
                    <th className="pb-4 font-medium">Cases Processed</th>
                    <th className="pb-4 font-medium">Letters Generated</th>
                    <th className="pb-4 font-medium">Clean Claims</th>
                    <th className="pb-4 font-medium">Clean Claim Rate</th>
                    <th className="pb-4 font-medium">Avg Letter Time</th>
                  </tr>
                </thead>
                <tbody>
                  {weeklyMetrics.map((week, i) => (
                    <tr key={i} className="border-b border-slate-50">
                      <td className="py-4 font-medium">{week.week}</td>
                      <td className="py-4">{week.cases}</td>
                      <td className="py-4">{week.letters}</td>
                      <td className="py-4">{week.cleanClaims}</td>
                      <td className="py-4">
                        <span className={`font-semibold ${(week.cleanClaims/week.cases)*100 >= 90 ? 'text-emerald-600' : 'text-amber-600'}`}>
                          {((week.cleanClaims/week.cases)*100).toFixed(0)}%
                        </span>
                      </td>
                      <td className="py-4">{week.avgLetterTime} min</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Add Case Modal */}
      {showAddCase && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold">Add New Case</h2>
              <button onClick={() => setShowAddCase(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Patient Initials</label>
                  <input type="text" className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., JD" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Date of Service</label>
                  <input type="date" className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Procedure</label>
                <select className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>All-on-4 Maxilla</option>
                  <option>All-on-4 Mandible</option>
                  <option>All-on-6 Bilateral</option>
                  <option>Full Arch Maxilla</option>
                  <option>Full Arch Mandible</option>
                  <option>Full Arch + Bone Graft</option>
                  <option>Zygomatic Implants</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Clinic</label>
                  <select className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>Clinic 1</option>
                    <option>Clinic 2</option>
                    <option>Clinic 3</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Insurance</label>
                  <input type="text" className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., UnitedHealthcare" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Total Fee</label>
                <input type="number" className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="50000" />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAddCase(false)} className="flex-1 px-4 py-3 border border-slate-200 rounded-lg font-medium hover:bg-slate-50 transition-colors">
                  Cancel
                </button>
                <button type="submit" className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
                  Add Case
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
