import React, { useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Brain, FileText, Send, DollarSign, AlertCircle, CheckCircle, Clock, Users, TrendingUp, Zap, Shield, MessageSquare, Calendar, ChevronRight, Bell, Search, Menu, X } from 'lucide-react';

const revenueData = [
  { month: 'Jul', collected: 145000, pending: 85000, denied: 12000 },
  { month: 'Aug', collected: 178000, pending: 72000, denied: 8000 },
  { month: 'Sep', collected: 195000, pending: 65000, denied: 6000 },
  { month: 'Oct', collected: 223000, pending: 58000, denied: 5000 },
  { month: 'Nov', collected: 248000, pending: 52000, denied: 4000 },
  { month: 'Dec', collected: 276000, pending: 48000, denied: 3500 },
];

const claimStatusData = [
  { name: 'Paid', value: 156, color: '#10B981' },
  { name: 'Pending', value: 42, color: '#F59E0B' },
  { name: 'In Auth', value: 28, color: '#3B82F6' },
  { name: 'Denied', value: 8, color: '#EF4444' },
];

const recentClaims = [
  { id: 'CLM-2847', patient: 'Robert Martinez', procedure: 'Full Arch Maxilla', amount: 47500, status: 'approved', payer: 'UnitedHealthcare', daysInAR: 12 },
  { id: 'CLM-2846', patient: 'Susan Williams', procedure: 'Full Arch Mandible', amount: 52000, status: 'pending', payer: 'Aetna', daysInAR: 18 },
  { id: 'CLM-2845', patient: 'James Thompson', procedure: 'All-on-4 Bilateral', amount: 89500, status: 'in_auth', payer: 'Cigna', daysInAR: 5 },
  { id: 'CLM-2844', patient: 'Maria Garcia', procedure: 'Full Arch + Bone Graft', amount: 61000, status: 'denied', payer: 'Blue Cross', daysInAR: 24 },
  { id: 'CLM-2843', patient: 'David Chen', procedure: 'Zygomatic Implants', amount: 78000, status: 'approved', payer: 'Medicare + Supp', daysInAR: 32 },
];

const aiTasks = [
  { type: 'doc', title: 'Medical Necessity Letter Generated', patient: 'John Anderson', time: '2 min ago', status: 'complete' },
  { type: 'code', title: 'Claim Coded & Validated', patient: 'Sarah Miller', time: '5 min ago', status: 'complete' },
  { type: 'auth', title: 'Prior Auth Submitted to Aetna', patient: 'Michael Brown', time: '12 min ago', status: 'pending' },
  { type: 'appeal', title: 'Appeal Letter Generated', patient: 'Emily Davis', time: '18 min ago', status: 'ready' },
  { type: 'payment', title: 'ERA Auto-Posted - $47,500', patient: 'Robert Martinez', time: '1 hr ago', status: 'complete' },
];

export default function ImplantBillDashboard() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showAIChat, setShowAIChat] = useState(false);
  const [chatMessage, setChatMessage] = useState('');

  const StatusBadge = ({ status }) => {
    const styles = {
      approved: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      pending: 'bg-amber-100 text-amber-700 border-amber-200',
      in_auth: 'bg-blue-100 text-blue-700 border-blue-200',
      denied: 'bg-red-100 text-red-700 border-red-200',
    };
    const labels = { approved: 'Paid', pending: 'Pending', in_auth: 'In Auth', denied: 'Denied' };
    return (
      <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  const MetricCard = ({ icon: Icon, label, value, change, color }) => (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-xl ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        {change && (
          <span className={`text-sm font-medium ${change > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {change > 0 ? '↑' : '↓'} {Math.abs(change)}%
          </span>
        )}
      </div>
      <p className="text-slate-500 text-sm font-medium">{label}</p>
      <p className="text-2xl font-bold text-slate-800 mt-1">{value}</p>
    </div>
  );

  const AITaskItem = ({ task }) => {
    const icons = { doc: FileText, code: Zap, auth: Send, appeal: AlertCircle, payment: DollarSign };
    const Icon = icons[task.type];
    const statusColors = { complete: 'text-emerald-500', pending: 'text-amber-500', ready: 'text-blue-500' };
    
    return (
      <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer">
        <div className="p-2.5 bg-white rounded-lg shadow-sm">
          <Icon className="w-5 h-5 text-indigo-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-slate-800 truncate">{task.title}</p>
          <p className="text-sm text-slate-500">{task.patient}</p>
        </div>
        <div className="text-right">
          <p className={`text-sm font-medium capitalize ${statusColors[task.status]}`}>{task.status}</p>
          <p className="text-xs text-slate-400">{task.time}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">ImplantBill AI</h1>
                <p className="text-xs text-slate-500">Full Arch Medical Billing Platform</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input 
                  type="text" 
                  placeholder="Search patients, claims..." 
                  className="pl-10 pr-4 py-2.5 bg-slate-100 rounded-xl text-sm w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                />
              </div>
              <button className="relative p-2.5 hover:bg-slate-100 rounded-xl transition-colors">
                <Bell className="w-5 h-5 text-slate-600" />
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
                <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face" className="w-10 h-10 rounded-full object-cover" alt="User" />
                <div className="hidden md:block">
                  <p className="text-sm font-semibold text-slate-800">Dr. Sarah Chen</p>
                  <p className="text-xs text-slate-500">Advanced Implant Center</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-[1600px] mx-auto px-6 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard icon={DollarSign} label="Collected This Month" value="$276,000" change={12} color="bg-emerald-500" />
          <MetricCard icon={CheckCircle} label="Clean Claim Rate" value="96.2%" change={4} color="bg-blue-500" />
          <MetricCard icon={Clock} label="Avg Days to Payment" value="32 days" change={-18} color="bg-indigo-500" />
          <MetricCard icon={TrendingUp} label="Appeal Success Rate" value="78%" change={8} color="bg-purple-500" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Revenue Chart */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-800">Revenue Performance</h2>
                  <p className="text-sm text-slate-500">Medical insurance collections over time</p>
                </div>
                <select className="px-4 py-2 bg-slate-100 rounded-lg text-sm font-medium text-slate-600 focus:outline-none">
                  <option>Last 6 Months</option>
                  <option>Last 12 Months</option>
                  <option>This Year</option>
                </select>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
                  <YAxis stroke="#64748B" fontSize={12} tickFormatter={(v) => `$${v/1000}k`} />
                  <Tooltip formatter={(v) => `$${v.toLocaleString()}`} />
                  <Bar dataKey="collected" fill="#10B981" radius={[4, 4, 0, 0]} name="Collected" />
                  <Bar dataKey="pending" fill="#F59E0B" radius={[4, 4, 0, 0]} name="Pending" />
                  <Bar dataKey="denied" fill="#EF4444" radius={[4, 4, 0, 0]} name="Denied" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Recent Claims */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-800">Recent Claims</h2>
                  <p className="text-sm text-slate-500">Latest full arch implant submissions</p>
                </div>
                <button className="px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2">
                  View All <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-sm text-slate-500 border-b border-slate-100">
                      <th className="pb-4 font-medium">Claim ID</th>
                      <th className="pb-4 font-medium">Patient</th>
                      <th className="pb-4 font-medium">Procedure</th>
                      <th className="pb-4 font-medium">Amount</th>
                      <th className="pb-4 font-medium">Payer</th>
                      <th className="pb-4 font-medium">Days in AR</th>
                      <th className="pb-4 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentClaims.map((claim) => (
                      <tr key={claim.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors cursor-pointer">
                        <td className="py-4 font-mono text-sm text-indigo-600 font-semibold">{claim.id}</td>
                        <td className="py-4 font-medium text-slate-800">{claim.patient}</td>
                        <td className="py-4 text-slate-600 text-sm">{claim.procedure}</td>
                        <td className="py-4 font-semibold text-slate-800">${claim.amount.toLocaleString()}</td>
                        <td className="py-4 text-slate-600 text-sm">{claim.payer}</td>
                        <td className="py-4">
                          <span className={`font-medium ${claim.daysInAR > 30 ? 'text-amber-600' : 'text-slate-600'}`}>
                            {claim.daysInAR} days
                          </span>
                        </td>
                        <td className="py-4"><StatusBadge status={claim.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Claim Status Pie */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h2 className="text-lg font-bold text-slate-800 mb-6">Claim Status Overview</h2>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={claimStatusData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={4} dataKey="value">
                    {claimStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 gap-4 mt-4">
                {claimStatusData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                    <span className="text-sm text-slate-600">{item.name}</span>
                    <span className="text-sm font-bold text-slate-800 ml-auto">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Activity Feed */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg">
                    <Brain className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-800">AI Activity</h2>
                    <p className="text-xs text-slate-500">Automated tasks</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">Live</span>
              </div>
              <div className="space-y-3">
                {aiTasks.map((task, i) => (
                  <AITaskItem key={i} task={task} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Chat Button */}
      <button 
        onClick={() => setShowAIChat(!showAIChat)}
        className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full shadow-lg shadow-indigo-300 flex items-center justify-center hover:scale-105 transition-transform z-50"
      >
        {showAIChat ? <X className="w-7 h-7 text-white" /> : <MessageSquare className="w-7 h-7 text-white" />}
      </button>

      {/* AI Chat Panel */}
      {showAIChat && (
        <div className="fixed bottom-28 right-8 w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold">ImplantBot AI</h3>
                <p className="text-indigo-200 text-xs">Your billing assistant</p>
              </div>
            </div>
          </div>
          <div className="h-80 p-4 bg-slate-50 overflow-y-auto">
            <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
              <p className="text-sm text-slate-600">👋 Hi Dr. Chen! How can I help you today?</p>
              <div className="mt-3 space-y-2">
                <button className="w-full text-left px-3 py-2 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-sm text-indigo-700 transition-colors">
                  Generate medical necessity letter
                </button>
                <button className="w-full text-left px-3 py-2 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-sm text-indigo-700 transition-colors">
                  Check prior auth status
                </button>
                <button className="w-full text-left px-3 py-2 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-sm text-indigo-700 transition-colors">
                  Create appeal for denied claim
                </button>
              </div>
            </div>
          </div>
          <div className="p-4 border-t border-slate-200">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Ask anything about billing..." 
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                className="flex-1 px-4 py-3 bg-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button className="p-3 bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors">
                <Send className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
